#!/usr/bin/env bash
# Cell 45 bundle (2026-10-03): serving standard D73 (V1, neutral generation config, chunked prefill), gpuq3.sh,
# paraphrase filter D74, Llama ModelOpt D75; stops all lanes and moves superseded outputs to quarantine (nothing deleted).
set -e
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src
cd $PROJ
cat > $PROJ/src/coalrag/experiments/e5_wave2.py <<'E5W2'
"""Wave 2 (D60). Reuses the pre-registered e4 runner unchanged: main conditions are delegated to e4_llm.Runner.run_one,
new conditions build prompts here and are scored with the same option-likelihood method.
  F  evidence-intervention factorial on the oracle precedent (one precedent, identical text across arms)
  R  order and k robustness of stratified evidence
  P  Choi et al. paraphrase templates (auto-discovered in VoteTemplates.py), zero-shot and with stratified evidence
  M  memorization probe (draft symbol and date only)
  AR all-regime run (use --queries adopted)
  --think off|on  Qwen3 reasoning mode: off = empty think block; on = sampled reasoning (budget-forced), then scoring
Output: results/store/e4_{served}_{tag}.jsonl, same schema as e4 plus optional fields (shown, template, think, ...)."""
import argparse, ast, asyncio, json, math, os, random, re, string, time
from pathlib import Path
from coalrag.core.match import P5
from coalrag.retrieval.configA import ConfigA, NAME
from coalrag.llm.client import LLM, verify_served, OPTS, LBL
from coalrag.llm import prompts as PR
from coalrag.experiments import e4_llm as E4

PROJ = Path(os.environ["PROJ"]); STORE = PROJ / "results" / "store"; LOGS = PROJ / "logs"; HOME = Path.home()
for k, v in {"qwen2.5-32b-gptq-int8": HOME / "models/Qwen2.5-32B-Instruct-GPTQ-Int8",
             "mistral-small-24b-2501-fp8": HOME / "models/Mistral-Small-24B-Instruct-2501-FP8-dynamic",
             "qwen3-8b": HOME / "models/Qwen3-8B"}.items():
    E4.MODELS.setdefault(k, str(v))
WORD, ctx = E4.WORD, E4.ctx
FLIP = {"Y": "N", "N": "Y", "A": "N"}
MEM = ("You are a representative of {country} in the United Nations Security Council (UNSC).\n"
       "On {date}, the Security Council voted on draft resolution {symbol}.\n"
       "How did {country} vote on this draft? The vote must be one of three options: favour, against, or abstention.\n\n{fmt}")
GROUPS = {
    "F": ["F-orc-text", "F-orc-coal", "F-orc-flip", "F-orc-others", "F-rnd-coal", "F-rnd-orcv"],
    "R": ["R-strat4-rev", "R-strat4-shuf", "R-strat2-coal", "R-strat6-coal"],
    "M": ["M-symbol"],
    "AR": ["B0-std", "D-bge-coal", "D-strat4-coal"],
    "THINK": ["B0-std", "D-bge-coal", "D-random-coal", "D-oracle-coal", "D-strat4-coal", "F-orc-coal", "F-orc-flip"]}
SENT = "@@DRAFT@@"


def choi_paraphrases(limit=4, verbose=False):
    """String templates in Choi's VoteTemplates.py that (i) take a country and a draft, (ii) are single-turn vote prompts
    (no history or reflexion), (iii) differ from the templates already used in the main run. Keys are STABLE ids: the
    position of the string among all string constants in the file (D71), so changing this filter never renumbers P-conditions."""
    src = next((PROJ / "data/raw/Nation-Level_Bias").rglob("VoteTemplates.py"), None)
    if src is None: return {}
    found = []
    for node in ast.walk(ast.parse(src.read_text(encoding="utf-8"))):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)): continue
        tg = node.targets[0] if isinstance(node, ast.Assign) else node.target
        name = tg.id if isinstance(tg, ast.Name) else getattr(tg, "attr", "anon")
        val = node.value
        if isinstance(val, ast.Constant): items = [(name, val)]
        elif isinstance(val, (ast.List, ast.Tuple)): items = [(f"{name}[{i}]", v) for i, v in enumerate(val.elts)]
        elif isinstance(val, ast.Dict): items = [(f"{name}[{getattr(k, 'value', i)}]", v) for i, (k, v) in enumerate(zip(val.keys, val.values))]
        else: items = []
        found += [(n, v.value) for n, v in items if isinstance(v, ast.Constant) and isinstance(v.value, str)]
    norm = lambda t: re.sub(r"\s+", " ", t).strip()
    seen = {norm(t) for t in (PR.BASIC, PR.WITH_HISTORY, PR.WITHOUT_HISTORY, PR.REFLEXION)}; out = {}
    def classify(t):
        low = t.lower()
        if "against" not in low: return "no 'against'", None
        bad = [w for w in ("predecessor", "previous", "histor") if w in low]  # D74: "reflect" removed
        if bad: return f"history/reflexion word {bad}", None
        try: fields = {f for _, f, _, _ in string.Formatter().parse(t) if f}
        except ValueError: return "unparseable braces", None
        role = {}
        for f in fields:
            fl = f.lower()
            if "country" in fl or "nation" in fl: role[f] = "country"
            elif "format" in fl: role[f] = "fmt"
            elif any(w in fl for w in ("resolution", "query", "draft", "context")): role[f] = "draft"
            else: return f"unknown field {{{f}}}", None
        if "draft" not in role.values() or "country" not in role.values(): return f"fields {sorted(fields)}", None
        if norm(t) in seen: return "duplicate of a used template", None
        try: t.format(**{f: "x" for f in role})
        except Exception as e: return f"format error {type(e).__name__}", None
        return None, role
    for i, (name, t) in enumerate(found, 1):
        why, role = classify(t)
        if why is None and len(out) < limit: seen.add(norm(t)); out[i] = (name, t, role)
        if verbose: print(f"  #{i:<3d} {name[:38]:38s} {'ACCEPT -> P' + str(i) if i in out else 'reject: ' + (why or 'over limit'):42s} | {norm(t)[:80]}")
    return out


def para_prompt(tpl, role, country, q, blk=""):
    u = tpl.format(**{f: (country if r == "country" else PR.ANSWER_ONE_WORD if r == "fmt" else SENT) for f, r in role.items()})
    if "fmt" not in role.values(): u = u.rstrip() + "\n\n" + PR.ANSWER_ONE_WORD
    if blk:  # evidence goes before the draft header line, as in the main D-conditions
        L = u.split("\n"); i = next(j for j, l in enumerate(L) if SENT in l)
        if L[i].strip() == SENT and i > 0 and "draft" in L[i - 1].lower() and len(L[i - 1]) < 80: i -= 1
        L.insert(i, blk.rstrip("\n")); u = "\n".join(L)
    return u.replace(SENT, ctx(q))


def block(cfg, slots, n, view, over=None):
    """Identical layout to prompts.precedent_block, plus view 'others' and displayed-vote overrides (res_id -> votes)."""
    if not slots: return ""
    L = ["Consider the following similar past draft resolutions in <similar_past_resolutions>.", "<similar_past_resolutions>"]
    for i, d in enumerate(slots, 1):
        L.append(f"[{i}] Date: {d['date'].date()} | Outcome: {'adopted' if d['adopted'] else 'not adopted'}")
        L.append(f"Summary: {d.get('summary') or ''}")
        v = (over or {}).get(d["res_id"], cfg.vot[d["res_id"]])
        if view == "target": L.append(f"Vote of {NAME[n]}: {WORD[v[n]]}")
        if view == "coalition": L.append("Votes of the permanent members: " + "; ".join(f"{NAME[m]}: {WORD[v[m]]}" for m in P5))
        if view == "others": L.append("Votes of the other permanent members: " + "; ".join(f"{NAME[m]}: {WORD[v[m]]}" for m in P5 if m != n))
    L.append("</similar_past_resolutions>")
    return "\n".join(L) + "\n"


def d_prompt(country, q, blk):
    """Exactly the e4 D-condition construction: WITHOUT_HISTORY with the evidence block before the draft header."""
    u = PR.WITHOUT_HISTORY.format(country=country, answer_format=PR.ANSWER_ONE_WORD, query=ctx(q))
    return u.replace("<draft_resolution> :", blk + "\n<draft_resolution> :", 1)


async def score_prefix(llm, prefix):
    pre = llm.tok(prefix, add_special_tokens=False).input_ids
    lps = await asyncio.gather(*[llm._lp(prefix, pre, o) for o in OPTS])
    z = max(lps); w = [math.exp(v - z) for v in lps]; s = sum(w)
    return {LBL[o]: w[i] / s for i, o in enumerate(OPTS)}, len(pre)


async def think_prefix(llm, user, mode, budget):
    base = llm.tok.apply_chat_template([{"role": "user", "content": user}], tokenize=False, add_generation_prompt=True,
                                       enable_thinking=(mode == "on"))
    if mode == "off": return base, {}
    async with llm.sem:
        r = await llm.cli.completions.create(model=llm.m, prompt=base, max_tokens=budget, temperature=0.6, top_p=0.95, seed=0,
                                             stop=["</think>"], extra_body={"add_special_tokens": False, "top_k": 20})
    c = r.choices[0]; txt = c.text or ""
    if "<think>" not in txt[:20]: txt = "<think>\n" + txt.lstrip()
    return base + txt.rstrip() + "\n</think>\n\n", {"reason_tokens": r.usage.completion_tokens, "truncated": c.finish_reason == "length"}


class W2(E4.Runner):
    def __init__(self, llm, cfg, out, think="none", budget=1024, paras=None):
        super().__init__(llm, cfg, out)
        for k, v in dict(cache={}, samples={}, lock=asyncio.Lock(), n=0, t0=time.time()).items():
            if not hasattr(self, k): setattr(self, k, v)
        self.out, self.think, self.budget, self.paras = out, think, budget, dict(paras or {})

    @staticmethod
    def qset(q): return q.get("regime") if q["adopted"] else ("vetoed" if q["vetoed"] else "failed")

    def fslots(self, q, n, cond):
        cfg = self.cfg; o = cfg.oracle(q)
        if o is None: return None
        doc = o
        if cond.startswith("F-rnd"):
            pool = [c for c in cfg.eligible(q, cfg.A if o["adopted"] else cfg.N) if c["res_id"] != o["res_id"]]
            if not pool: return None
            doc = random.Random(f"{q['res_id']}|rnd").choice(pool)
        view, over = {"text": "text", "others": "others"}.get(cond.split("-")[-1], "coalition"), None
        if cond == "F-orc-flip":
            v = dict(cfg.vot[o["res_id"]]); v[n] = FLIP[v[n]]; over = {o["res_id"]: v}
        if cond == "F-rnd-orcv": over = {doc["res_id"]: dict(cfg.vot[o["res_id"]])}
        shown = (over or {}).get(doc["res_id"], cfg.vot[doc["res_id"]])[n] if view == "coalition" else None
        return doc, view, over, shown

    def rslots(self, q, cond):
        c = self.cfg
        if cond == "R-strat4-rev": return list(c.strat_slots(q, 4, True))[::-1]
        if cond == "R-strat4-shuf":
            s = list(c.strat_slots(q, 4, True)); random.Random(f"{q['res_id']}|shuf").shuffle(s); return s
        return c.strat_slots(q, int(cond[len("R-strat")]), True)

    async def build(self, q, n, cond):
        cfg, country = self.cfg, NAME[n]
        if cond == "B0-std": return PR.WITHOUT_HISTORY.format(country=country, answer_format=PR.ANSWER_ONE_WORD, query=ctx(q)), [], {}
        if cond.startswith("D-"):
            sl = self.slots(q, cond); view = {"text": "text", "target": "target", "coal": "coalition"}[cond.split("-")[-1]]
            return d_prompt(country, q, PR.precedent_block(sl, view, n, cfg.vot, NAME, WORD, P5)), [d["res_id"] for d in sl], {}
        if cond.startswith("F-"):
            r = self.fslots(q, n, cond)
            if r is None: return None
            doc, view, over, shown = r
            return d_prompt(country, q, block(cfg, [doc], n, view, over)), [doc["res_id"]], {"shown": shown}
        if cond.startswith("R-"):
            sl = self.rslots(q, cond)
            return d_prompt(country, q, block(cfg, sl, n, "coalition")), [d["res_id"] for d in sl], {}
        if cond.startswith("M-"):
            return MEM.format(country=country, date=q["date"].date().isoformat(), symbol=q["symbol"], fmt=PR.ANSWER_ONE_WORD), [], {}
        m = re.fullmatch(r"P(\d+)-(B0|strat4)", cond)
        if m:
            name, tpl, role = self.paras[int(m.group(1))]
            sl = cfg.strat_slots(q, 4, True) if m.group(2) == "strat4" else []
            return para_prompt(tpl, role, country, q, block(cfg, sl, n, "coalition")), [d["res_id"] for d in sl], {"template": name}
        raise ValueError(f"unknown condition {cond}")

    async def run_one(self, q, n, cond):
        if cond in E4.CONDS and not q["adopted"] and self.think == "none":
            return await super().run_one(q, n, cond)
        t = time.time(); err = p = ntok = None; ret = []; extra = {}
        try:
            b = await self.build(q, n, cond)
            if b is None: return
            user, ret, extra = b
            self.samples.setdefault(cond, f"[{q['symbol']} | {NAME[n]}]\n{user}")
            if self.think == "none": p, ntok = await self.llm.score(user)
            else:
                pre, info = await think_prefix(self.llm, user, self.think, self.budget); extra.update(info)
                p, ntok = await score_prefix(self.llm, pre)
        except Exception as e:
            err = f"{type(e).__name__}: {str(e)[:200]}"
        rec = dict(qid=q["res_id"], symbol=q["symbol"], qset=self.qset(q), nation=n, cond=cond, model=self.llm.m,
                   pY=p["Y"] if p else None, pN=p["N"] if p else None, pA=p["A"] if p else None,
                   pred=max(p, key=p.get) if p else None, true=self.cfg.vot[q["res_id"]][n], retrieved=ret,
                   prompt_tokens=ntok, sec=round(time.time() - t, 2), error=err, think=self.think, **extra)
        async with self.lock:
            with open(self.out, "a") as f: f.write(json.dumps(rec) + "\n")
            self.n += 1
            if self.n % 200 == 0: print(f"  {self.n} done | {time.time() - self.t0:.0f}s", flush=True)


def expand(spec, paras):
    G = dict(GROUPS, main=list(E4.CONDS), P=[f"P{i}-{k}" for i in paras for k in ("B0", "strat4")])
    G["wave2"] = G["F"] + G["R"] + G["P"] + G["M"]
    out = []
    for tok in spec.split(","):
        out += G.get(tok, [tok])
    return list(dict.fromkeys(out))


def selftest(cfg):
    """The local block builder must reproduce prompts.precedent_block exactly for the shared views."""
    for q in cfg.N[:5]:
        sl = cfg.strat_slots(q, 4, True)
        for view in ("text", "target", "coalition"):
            for n in P5:
                assert block(cfg, sl, n, view) == PR.precedent_block(sl, view, n, cfg.vot, NAME, WORD, P5), (q["res_id"], view, n)
    print("[selftest] evidence block identical to e4 for text/target/coalition views")


async def amain(a):
    if a.list_templates: choi_paraphrases(verbose=True); return
    cfg = ConfigA(); selftest(cfg)
    llm = LLM(a.served, E4.MODELS[a.served], base=a.base, conc=a.conc)
    await verify_served(llm, E4.MODELS[a.served])
    paras = choi_paraphrases()
    print("paraphrase templates:", {f"P{i}": v[0] for i, v in paras.items()} or "NONE FOUND", flush=True)
    conds = expand(a.conds, paras)
    if a.think != "none" and any(c.startswith("CF-") or c == "B0-choi" for c in conds): raise SystemExit("--think supports B0-std, D-*, F-*, R-*, P*, M-*")
    Q = sorted({"nonadopted": cfg.N, "adopted": cfg.A, "all": cfg.A + cfg.N}[a.queries], key=lambda r: r["date"])
    if a.limit: Q = Q[::max(1, len(Q) // a.limit)][:a.limit]
    out = STORE / f"e4_{a.served}_{a.tag}.jsonl"; done = set()
    if out.exists():
        for l in open(out):
            r = json.loads(l)
            if r.get("error") is None: done.add((r["qid"], r["nation"], r["cond"]))
    has_orc = {q["res_id"]: cfg.oracle(q) is not None for q in Q} if any(c.startswith("F-") for c in conds) else {}
    def want(q, n, c):
        if (q["res_id"], n, c) in done: return False
        if c in E4.CONDS and not q["adopted"] and a.think == "none": return True
        if cfg.vot[q["res_id"]][n] not in ("Y", "N", "A"): return False
        return has_orc.get(q["res_id"], True) if c.startswith("F-") else True
    R = W2(llm, cfg, out, a.think, a.budget, paras); t = time.time()
    tasks = [R.run_one(q, n, c) for c in conds for q in Q for n in P5 if want(q, n, c)]
    print(f"{len(tasks)} tasks | {len(Q)} {a.queries} queries | {len(conds)} conditions | think={a.think} | model {a.served}", flush=True)
    await asyncio.gather(*tasks)
    print(f"wall {time.time() - t:.0f}s")
    (LOGS / f"e4_prompt_samples_{a.served}_{a.tag}.txt").write_text("\n\n".join(f"########## {k}\n{v}" for k, v in R.samples.items()))
    rows = [json.loads(l) for l in open(out)] if out.exists() else []
    bad = sum(1 for r in rows if r.get("error")); print(f"rows={len(rows)} error_rows={bad}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--served", default=""); ap.add_argument("--conds", default="wave2"); ap.add_argument("--tag", default="wave2")
    ap.add_argument("--queries", default="nonadopted", choices=["nonadopted", "adopted", "all"]); ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--conc", type=int, default=10); ap.add_argument("--base", default="http://127.0.0.1:8007/v1")
    ap.add_argument("--think", default="none", choices=["none", "off", "on"]); ap.add_argument("--budget", type=int, default=1024)
    ap.add_argument("--list-templates", action="store_true")
    asyncio.run(amain(ap.parse_args()))
E5W2
cat > $PROJ/configs/gpuq3.sh <<'GPUQ3'
#!/usr/bin/env bash
# Two-GPU queue v3 (D73). Single serving standard for every model:
#   vLLM V1 engine, --generation-config vllm (neutral sampling: no model-default repetition penalty),
#   chunked prefill with --max-num-batched-tokens 2048 (bounds the prompt log-prob tensor), --max-model-len 8192,
#   and a preflight that scores 8 near-maximum-length prompts concurrently before any run.
#   bash gpuq3.sh stop    stop all lanes (v1-v3), LLM clients and this user's servers on GPUs 7 and 9
#   bash gpuq3.sh diag    coverage, errors, prompt lengths, Llama format, template audit
#   bash gpuq3.sh lane9   GPU 9 :8001  32B main (pre-registered e4 runner) -> 32B all-regime -> 32B wave 2
#   bash gpuq3.sh lane7   GPU 7 :8007  Mistral-24B-2501 main + F,M -> Qwen2.5-7B main + F,M -> Qwen3-8B thinking off/on
#   bash gpuq3.sh tp2     GPUs 7+9 :8007  waits for both lanes, then Llama-3.3-70B-FP8 (reduced set + F)
set -u
LANE=${1:?usage: gpuq3.sh stop|diag|lane9|lane7|tp2}
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src CUDA_DEVICE_ORDER=PCI_BUS_ID
L=$PROJ/logs/gpuq3.log
say() { echo "[$(date '+%m-%d %H:%M:%S')] [$LANE] $*" | tee -a $L; }
served() { curl -s -m 10 127.0.0.1:$1/v1/models | python -c "import sys,json; print(json.load(sys.stdin)['data'][0]['id'])" 2>/dev/null; }
cov() { python -m coalrag.tools.diag 2>/dev/null | grep "^e4_$1_$2.jsonl" | cut -d'|' -f1-3; }
free_gpu() {  # this user's processes on the listed GPUs, plus their 'vllm serve' parent
  for g in ${1//,/ }; do
    for p in $(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader); do
      [ "$(ps -o user= -p $p 2>/dev/null | tr -d ' ')" = "$USER" ] || continue
      pp=$(ps -o ppid= -p $p | tr -d ' '); ps -o cmd= -p $pp | grep -q "vllm serve" && kill $pp; kill $p 2>/dev/null
    done
  done; sleep 30
}
stop_port() { pkill -u $USER -f "vllm serve.*--port $1( |$)"; sleep 5; }
serve_chain() {  # $1 GPUs, $2 port, $3 checkpoint, $4 served name, then one quoted string of vllm args per configuration
  local G=$1 P=$2 M=$3 N=$4; shift 4
  [ -f "$M/config.json" ] || { say "SKIP $N: $M missing"; return 1; }
  for cfg in "$@"; do
    stop_port $P; free_gpu $G
    conda activate crag-vllm
    VLLM_USE_V1=1 CUDA_VISIBLE_DEVICES=$G nohup vllm serve $M --served-model-name $N --host 127.0.0.1 --port $P --seed 0 \
      --generation-config vllm --max-model-len 8192 --max-num-batched-tokens 2048 --max-num-seqs 16 $cfg \
      > $PROJ/logs/vllm_${N}_$P.log 2>&1 &
    local pid=$! ok=0; conda activate crag
    for i in $(seq 1 360); do
      [ "$(served $P)" = "$N" ] && { ok=1; break; }; kill -0 $pid 2>/dev/null || break; sleep 5
    done
    if [ $ok = 1 ]; then
      local pf; pf=$(python -W ignore -m coalrag.tools.preflight $N http://127.0.0.1:$P/v1 8192 2>&1 | tail -1)
      say "$N on GPU $G :$P [$cfg] | $(grep -h 'KV cache size' $PROJ/logs/vllm_${N}_$P.log | tail -1 | sed 's/.*INFO[^]]*] //') | $pf"
      echo "$pf" | grep -q " 8/8 " && return 0
      say "  server log tail: $(grep -hE 'Error|error' $PROJ/logs/vllm_${N}_$P.log | tail -1 | cut -c1-200)"
    else
      say "$N failed to start [$cfg]: $(grep -hE 'Error|error' $PROJ/logs/vllm_${N}_$P.log | tail -1 | cut -c1-200)"
    fi
  done
  stop_port $P; say "SERVE FAILED $N (all configurations)"; return 1
}
e4main() {  # $1 port, $2 served name, $3 concurrency
  say "start $2 main (pre-registered e4 runner)"
  for pass in 1 2; do python -W ignore -m coalrag.experiments.e4_llm --served $2 --base http://127.0.0.1:$1/v1 --tag main --conc $3 >> $PROJ/logs/e4_$2_main.log 2>&1; done
  say "end   $2 main | $(cov $2 main)"
}
e5() {  # $1 port, $2 served name, $3 tag, rest = e5_wave2 args; two passes so transient errors are retried
  local P=$1 N=$2 T=$3; shift 3; say "start $N $T $*"
  for pass in 1 2; do python -W ignore -m coalrag.experiments.e5_wave2 --served $N --base http://127.0.0.1:$P/v1 --tag $T "$@" >> $PROJ/logs/e5_$N.log 2>&1; done
  say "end   $N $T | $(cov $N $T)"
}

stop() {
  pkill -u $USER -f "gpuq[23]?\.sh (lane|tp2)"; pkill -u $USER -f "queue_wave2.sh"
  pkill -u $USER -f "coalrag.experiments.e[45]"; pkill -u $USER -f "coalrag.tools.preflight"; sleep 3
  stop_port 8001; stop_port 8007; free_gpu 7,9
  for g in 7 9; do echo "GPU $g in use: $(nvidia-smi -i $g --query-gpu=memory.used --format=csv,noheader)"; done
}
diag() { python -W ignore -m coalrag.tools.diag; }
lane9() {
  local G=9 P=8001 N=qwen2.5-32b-gptq-int8
  serve_chain $G $P $HOME/models/Qwen2.5-32B-Instruct-GPTQ-Int8 $N \
    "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager" || return 1
  e4main $P $N 12
  e5 $P $N allreg --conds AR --queries adopted --conc 16
  e5 $P $N wave2 --conds wave2 --conc 12
}
lane7() {
  local G=7 P=8007 N=mistral-small-24b-2501-fp8
  if serve_chain $G $P $HOME/models/Mistral-Small-24B-Instruct-2501-FP8-dynamic $N \
       "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager"; then
    e5 $P $N main --conds main --conc 16
    e5 $P $N wave2 --conds F,M --conc 16
  fi
  N=qwen2.5-7b
  if serve_chain $G $P /mnt/nvme01/huggingface/models/Qwen/Qwen2.5-7B-Instruct $N \
       "--gpu-memory-utilization 0.80" "--gpu-memory-utilization 0.75 --enforce-eager"; then
    e5 $P $N main --conds main --conc 32
    e5 $P $N wave2 --conds F,M --conc 32
  fi
  N=qwen3-8b
  if serve_chain $G $P $HOME/models/Qwen3-8B $N \
       "--gpu-memory-utilization 0.80" "--gpu-memory-utilization 0.75 --enforce-eager"; then
    e5 $P $N think-off --conds THINK --think off --conc 32
    e5 $P $N think-on --conds THINK --think on --budget 1024 --conc 32
  fi
}
tp2() {
  local G=7,9 P=8007 N=llama-3.3-70b-fp8 M=/mnt/nvme01/huggingface/models/MetaAI/Llama-3.3-70B-Instruct-FP8
  say "waiting for lane9 and lane7 to finish and for every LLM client to exit"
  until grep -q "\[lane9\] lane9 done" $L && grep -q "\[lane7\] lane7 done" $L && ! pgrep -u $USER -f "coalrag.experiments.e[45]" >/dev/null; do sleep 300; done
  [ -f $M/hf_quant_config.json ] || { say "SKIP $N: no hf_quant_config.json"; return 1; }
  stop_port 8001
  serve_chain $G $P $M $N \
    "--tensor-parallel-size 2 --quantization modelopt --gpu-memory-utilization 0.88" \
    "--tensor-parallel-size 2 --quantization modelopt --gpu-memory-utilization 0.85 --enforce-eager" || return 1
  e5 $P $N main --conds B0-choi,B0-std,CF-LTorig,D-bge-coal,D-oracle-coal,D-random-coal,D-strat4-coal --conc 12
  e5 $P $N wave2 --conds F --conc 12
}
case $LANE in
  stop|diag) $LANE ;;
  lane9|lane7|tp2) trap 'say "$LANE done"' EXIT; say "started"; $LANE ;;
  *) echo "unknown lane $LANE"; exit 2 ;;
esac
GPUQ3
chmod +x $PROJ/configs/gpuq3.sh
echo "== stopping all lanes, clients and servers on GPUs 7 and 9 =="
bash $PROJ/configs/gpuq3.sh stop || true
echo "== quarantining outputs produced under mixed engines / generation configs (D73) =="
Qd=$PROJ/results/quarantine/superseded_D73; mkdir -p $Qd
for f in qwen2.5-32b-gptq-int8_main qwen2.5-32b-gptq-int8_allreg qwen2.5-32b-gptq-int8_wave2 qwen2.5-32b-gptq-int8_smoke \
         mistral-small-24b-2501-fp8_main mistral-small-24b-2501-fp8_wave2 qwen2.5-7b_main qwen2.5-7b_wave2 qwen3-8b_think-off qwen3-8b_think-on; do
  [ -f $PROJ/results/store/e4_$f.jsonl ] && mv $PROJ/results/store/e4_$f.jsonl $Qd/ && echo "  moved e4_$f.jsonl"
done
echo "== evidence for D73: generation configs the servers applied by default =="
grep -l "generation config" $PROJ/logs/vllm_*.log 2>/dev/null | head -5 | while read f; do echo "  $(basename $f): $(grep -h "generation config" $f | tail -1 | cut -c1-200)"; done
for m in /mnt/nvme01/huggingface/models/Qwen/Qwen2.5-7B-Instruct $HOME/models/Qwen2.5-32B-Instruct-GPTQ-Int8 $HOME/models/Mistral-Small-24B-Instruct-2501-FP8-dynamic $HOME/models/Qwen3-8B /mnt/nvme01/huggingface/models/MetaAI/Llama-3.3-70B-Instruct-FP8; do
  echo "  $(basename $m): $(python -c "import json,sys; d=json.load(open(sys.argv[1])); print({k: d[k] for k in d if k in ('repetition_penalty','temperature','top_p','top_k')})" $m/generation_config.json 2>/dev/null)"
done
echo "== how Choi selects among the five templates =="
grep -rn "template_list_without_history\|template_list_with_history" $PROJ/data/raw/Nation-Level_Bias --include=*.py | grep -v "VoteTemplates.py" | cut -c1-200 | head -8
echo "== paraphrase audit after D74 =="
python -W ignore -m coalrag.experiments.e5_wave2 --list-templates | grep -E "ACCEPT|without_history"
grep -q "^- D73" $PROJ/configs/DECISIONS.md || cat >> $PROJ/configs/DECISIONS.md <<'DEC'
- D73 Serving and decoding standard (supersedes D62, D68, D69): vLLM V1 engine; --generation-config vllm (neutral sampling defaults; by default vLLM had applied each model's generation_config.json, which for Qwen2.5 adds repetition_penalty 1.05 to the Choi rehearsal and reflection generation and, under the V0 engine, to the scored logits; the V0 penalty step also caused the 3.4 GiB OOM in get_token_bin_counts_and_mask); chunked prefill with --max-num-batched-tokens 2048, which bounds the prompt log-probability tensor to about 1.2 GiB; --max-model-len 8192 (longest prompt 4,666 tokens); a preflight of 8 concurrent near-maximum-length prompts before every run. All LLM outputs produced before 3 Oct under mixed engines and configurations are moved to results/quarantine/superseded_D73/ (kept, not deleted) and every model is rerun under this standard. The 7B pilot stays as a development artefact.
- D74 Paraphrase filter: "reflect" removed from the exclusion words (it occurs in ordinary instructions in template_list_without_history[1-3]); accepted paraphrases are template_list_without_history[1-4] (P8-P11); [0] is the main WITHOUT_HISTORY template.
- D75 Llama-3.3-70B-Instruct-FP8 is an NVIDIA ModelOpt checkpoint (FP8 weights, FP8 KV-cache scales, lm_head unquantised); served with --quantization modelopt, tensor parallel 2, KV cache in the default dtype.
DEC
python -m py_compile src/coalrag/experiments/e5_wave2.py && bash -n configs/gpuq3.sh
git add -A && git -c user.name=becky1 -c user.email=becky1@andlab commit -qm "D73-D75: serving standard, gpuq3, paraphrase filter; quarantine superseded outputs" && git log -1 --format="commit %h %ad" || echo "nothing new to commit"
