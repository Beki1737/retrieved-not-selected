#!/usr/bin/env bash
# Cell 49 bundle (2026-10-03): E7 selection experiment (GPU 6) and E8 corpus augmentation (CPU), pre-registered as
# H13-H15 and committed before any output; positioning decision D80; D81-D82. Writes files and commits only.
set -e
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src
cd $PROJ
ls $PROJ/results/store/e4_*_select.jsonl $PROJ/results/store/e8_augment.parquet 2>/dev/null && { echo "E7/E8 output already exists: pre-registration must precede it. Aborting."; exit 1; } || true
cat > $PROJ/src/coalrag/experiments/e7_select.py <<'E7S'
"""E7 selection experiment (pre-registered H13-H14, D81). D-strat4-coal shows four precedents with four different vote
configurations in one prompt, and the model gains nothing (H5 not supported), although one matching precedent alone helps
a lot (D-oracle-coal). E7 separates the two steps:
  slot scoring  each of the 4 stratified precedents is shown ALONE (coalition view; same construction as F-orc-coal)
                -> rows S-slot1..S-slot4 in results/store/e4_<served>_select.jsonl
  selection     once per draft, the model is asked which earlier draft is the closest precedent (texts only, no votes),
                scored by option likelihood over "1".."k" -> results/store/e7_<served>_selector.jsonl
Aggregations are fixed in analysis/e7_analysis.py before any output exists. Nothing is tuned."""
import argparse, asyncio, json, math, time
from coalrag.core.match import P5
from coalrag.retrieval.configA import ConfigA, NAME
from coalrag.llm.client import LLM, verify_served
from coalrag.experiments import e5_wave2 as W

E4, STORE = W.E4, W.STORE
SEL = ("You will read a draft resolution submitted to the United Nations Security Council (UNSC) and {k} earlier draft resolutions.\n"
       "Which earlier draft is the closest precedent for the current draft, that is, the one concerning the same situation "
       "and proposing the same kind of action?\n\n<earlier_drafts>\n{blocks}</earlier_drafts>\n\n<current_draft>\n{query}\n</current_draft>\n\n"
       "Answer with the number of the closest precedent only ({opts}).")


def sel_block(slots):
    L = []
    for i, d in enumerate(slots, 1):
        L.append(f"[{i}] Date: {d['date'].date()} | Outcome: {'adopted' if d['adopted'] else 'not adopted'}")
        L.append(f"Summary: {d.get('summary') or ''}")
    return "\n".join(L) + "\n"


async def score_opts(llm, user, opts):
    prefix = llm.prefix(user); pre = llm.tok(prefix, add_special_tokens=False).input_ids
    lps = await asyncio.gather(*[llm._lp(prefix, pre, o) for o in opts])
    z = max(lps); w = [math.exp(v - z) for v in lps]; s = sum(w)
    return [x / s for x in w], len(pre)


async def amain(a):
    cfg = ConfigA(); llm = LLM(a.served, E4.MODELS[a.served], base=a.base, conc=a.conc)
    await verify_served(llm, E4.MODELS[a.served])
    Q = sorted(cfg.N, key=lambda r: r["date"])[: a.limit or None]
    out, sout = STORE / f"e4_{a.served}_select.jsonl", STORE / f"e7_{a.served}_selector.jsonl"
    done = {(r["qid"], r["nation"], r["cond"]) for r in map(json.loads, open(out)) if not r.get("error")} if out.exists() else set()
    sdone = {r["qid"] for r in map(json.loads, open(sout)) if not r.get("error")} if sout.exists() else set()
    lock = asyncio.Lock(); cnt = [0]; t0 = time.time(); sample = {}

    async def write(path, rec):
        async with lock:
            with open(path, "a") as f: f.write(json.dumps(rec) + "\n")
            cnt[0] += 1
            if cnt[0] % 200 == 0: print(f"  {cnt[0]} done | {time.time() - t0:.0f}s", flush=True)

    async def slot_task(q, n, i, doc):
        t = time.time(); err = p = ntok = None
        try:
            user = W.d_prompt(NAME[n], q, W.block(cfg, [doc], n, "coalition")); sample.setdefault("slot", user)
            p, ntok = await llm.score(user)
        except Exception as e:
            err = f"{type(e).__name__}: {str(e)[:200]}"
        await write(out, dict(qid=q["res_id"], symbol=q["symbol"], qset="vetoed" if q["vetoed"] else "failed", nation=n, cond=f"S-slot{i}",
                              slot=i, model=llm.m, pY=p["Y"] if p else None, pN=p["N"] if p else None, pA=p["A"] if p else None,
                              pred=max(p, key=p.get) if p else None, true=cfg.vot[q["res_id"]][n], retrieved=[doc["res_id"]],
                              prompt_tokens=ntok, sec=round(time.time() - t, 2), error=err))

    async def sel_task(q, slots):
        err = w = ntok = None; opts = [str(i) for i in range(1, len(slots) + 1)]
        try:
            user = SEL.format(k=len(slots), blocks=sel_block(slots), query=E4.ctx(q), opts=", ".join(opts)); sample.setdefault("selector", user)
            w, ntok = await score_opts(llm, user, opts)
        except Exception as e:
            err = f"{type(e).__name__}: {str(e)[:200]}"
        await write(sout, dict(qid=q["res_id"], ids=[d["res_id"] for d in slots], w=w, model=llm.m, prompt_tokens=ntok, error=err))

    tasks = []
    for q in Q:
        slots = list(cfg.strat_slots(q, 4, True))
        if not slots: continue
        if q["res_id"] not in sdone: tasks.append(sel_task(q, slots))
        for n in P5:
            if cfg.vot[q["res_id"]][n] not in ("Y", "N", "A"): continue
            tasks += [slot_task(q, n, i, d) for i, d in enumerate(slots, 1) if (q["res_id"], n, f"S-slot{i}") not in done]
    print(f"{len(tasks)} tasks | {len(Q)} drafts | model {a.served}", flush=True)
    await asyncio.gather(*tasks)
    if sample: (W.LOGS / f"e7_prompt_samples_{a.served}.txt").write_text("\n\n".join(f"########## {k}\n{v}" for k, v in sample.items()))
    bad = sum(1 for p in (out, sout) if p.exists() for r in map(json.loads, open(p)) if r.get("error"))
    print(f"wall {time.time() - t0:.0f}s | error rows {bad}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--served", required=True); ap.add_argument("--base", default="http://127.0.0.1:8006/v1")
    ap.add_argument("--conc", type=int, default=16); ap.add_argument("--limit", type=int, default=0)
    asyncio.run(amain(ap.parse_args()))
E7S
cat > $PROJ/src/coalrag/analysis/e7_analysis.py <<'E7A'
"""E7 analysis (pre-registered H13-H14, D81; aggregation rules fixed before any E7 output exists).
From the four single-precedent predictions P_i (S-slot1..4, i = stratified rank) and the selector probabilities w_i:
  S-top1    P_1 alone (the most similar stratified precedent)
  S-mean    uniform mean of P_i
  S-rank    weights proportional to 1/i
  S-llmsel  weights w_i from the model's own choice of the closest precedent (texts only, no votes)   <- H13
  S-perfect the P_i of the slot whose five-vote configuration equals the draft's; S-mean if no slot matches  <- bound, H14
Decomposition: D-oracle - D-strat4 = (S-perfect - D-strat4) [selection] + (D-oracle - S-perfect) [coverage + presentation].
Tests: one-sided resolution-cluster paired bootstrap; Holm across models for the H13 AUROC test.
Usage: python -m coalrag.analysis.e7_analysis [--B 2000]"""
import argparse, json, os
from pathlib import Path
import numpy as np, pandas as pd
from coalrag.analysis.e4_metrics import metrics
from coalrag.analysis.e5_analysis import load, stat, align, table

STORE = Path(os.environ["PROJ"]) / "results" / "store"; K = ["qid", "nation"]; LAB = np.array(["Y", "N", "A"]); P5 = ["CHN", "FRA", "GBR", "RUS", "USA"]


def rows_from(base, P, cond):
    d = base.copy(); d["cond"] = cond; d["pY"], d["pN"], d["pA"] = P[:, 0], P[:, 1], P[:, 2]
    d["ptrue"] = P[np.arange(len(d)), d.true.map({"Y": 0, "N": 1, "A": 2}).values]
    d["pred"] = LAB[P.argmax(1)]; d["hit"] = (d.pred == d.true).astype(float); return d


def pboot(a, b, name, B, seed=0):
    a, b = align([a, b]); f = stat(name); q = a.qid.values; uq = np.unique(q)
    pos = {u: np.where(q == u)[0] for u in uq}; rng = np.random.default_rng(seed); bs = []
    for _ in range(B):
        ix = np.concatenate([pos[u] for u in rng.choice(uq, len(uq))]); bs.append(f(a.iloc[ix]) - f(b.iloc[ix]))
    bs = np.array(bs, float); bs = bs[~np.isnan(bs)]
    return f(a) - f(b), np.percentile(bs, 2.5), np.percentile(bs, 97.5), (1 + np.sum(bs <= 0)) / (len(bs) + 1)


def holm(p):
    p = np.asarray(p, float); o = np.argsort(p); adj = np.empty_like(p); run = 0.0
    for r, i in enumerate(o): run = max(run, min(1.0, (len(p) - r) * p[i])); adj[i] = run
    return adj


def build(m):
    S = load(m, "select"); main = load(m, "main")
    sel = {}
    p = STORE / f"e7_{m}_selector.jsonl"
    for r in map(json.loads, open(p)):
        if not r.get("error"): sel[r["qid"]] = (r["ids"], np.array(r["w"], float))
    from coalrag.retrieval.configA import ConfigA
    vot = ConfigA().vot
    out = {c: [] for c in ("S-top1", "S-mean", "S-rank", "S-llmsel", "S-perfect")}; meta = []
    for (q, n), g in S.groupby(K):
        g = g.sort_values("slot"); P = g[["pY", "pN", "pA"]].values.astype(float); k = len(g); base = g.iloc[[0]][["qid", "symbol", "qset", "nation", "true"]]
        ids = [r[0] for r in g.retrieved]; cfgq = tuple(vot[q][x] for x in P5)
        match = [i for i, d in enumerate(ids) if tuple(vot[d][x] for x in P5) == cfgq]
        wr = 1 / np.arange(1, k + 1); wr = wr / wr.sum()
        add = {"S-top1": P[0], "S-mean": P.mean(0), "S-rank": wr @ P, "S-perfect": P[match[0]] if match else P.mean(0)}
        if q in sel and len(sel[q][1]) == k: add["S-llmsel"] = (sel[q][1] / sel[q][1].sum()) @ P
        for c, v in add.items(): out[c].append((base, v))
        meta.append(dict(qid=q, nation=n, k=k, covered=bool(match), match_slot=(match[0] + 1) if match else None,
                         sel_argmax=int(np.argmax(sel[q][1])) + 1 if q in sel else None, w1=float(sel[q][1][0]) if q in sel else np.nan))
    agg = [rows_from(pd.concat([b for b, _ in v], ignore_index=True), np.vstack([x for _, x in v]), c) for c, v in out.items() if v]
    ref = main[main.cond.isin(["B0-std", "D-random-coal", "D-strat4-coal", "D-oracle-coal"])]
    return pd.concat([ref] + agg, ignore_index=True), pd.DataFrame(meta)


def main(B):
    models = sorted(p.name[3:-13] for p in STORE.glob("e4_*_select.jsonl"))
    tests, H13 = [], []
    for m in models:
        d, meta = build(m); d = pd.concat(align([g for _, g in d.groupby("cond")]))
        conds = ["B0-std", "D-random-coal", "D-strat4-coal", "S-top1", "S-mean", "S-rank", "S-llmsel", "S-perfect", "D-oracle-coal"]
        print(f"\n==== {m} | keys {d.groupby('cond').size().min()} ====")
        with pd.option_context("display.width", 200): print(table(d, [c for c in conds if c in set(d.cond)]).to_string())
        cov = meta.drop_duplicates("qid"); hit = cov[cov.covered]
        print(f"coverage: a stratified slot matches the draft's configuration for {cov.covered.mean():.1%} of drafts | "
              f"selector picks that slot in {np.mean(hit.sel_argmax == hit.match_slot):.1%} (slot-1 rule: {np.mean(hit.match_slot == 1):.1%}; "
              f"chance {np.mean(1 / hit.k):.1%}) | mean selector weight on slot 1 {cov.w1.mean():.2f}")
        g = {c: x for c, x in d.groupby("cond")}
        for h, k, a, b in [("H13", "aucN", "S-llmsel", "D-strat4-coal"), ("H13", "macroF1_BC", "S-llmsel", "D-strat4-coal"),
                           ("E", "aucN", "S-llmsel", "S-rank"), ("E", "aucN", "S-mean", "D-strat4-coal"),
                           ("H14", "aucN", "S-perfect", "D-strat4-coal"), ("E", "aucN", "D-oracle-coal", "S-perfect")]:
            if a in g and b in g:
                dl, lo, hi, p = pboot(g[a], g[b], k, B)
                tests.append(dict(model=m, hyp=h, metric=k, a=a, b=b, delta=dl, ci=f"[{lo:+.3f}, {hi:+.3f}]", p=p))
        if {"D-oracle-coal", "D-strat4-coal", "S-perfect"} <= set(g):
            f = stat("aucN"); o, s4, sp = f(g["D-oracle-coal"]), f(g["D-strat4-coal"]), f(g["S-perfect"])
            print(f"decomposition of the oracle gap in AUROC(N): total {o - s4:+.3f} = selection {sp - s4:+.3f} + coverage/presentation {o - sp:+.3f}")
    t = pd.DataFrame(tests)
    if len(t):
        i = t.index[(t.hyp == "H13") & (t.metric == "aucN")]; t["p_holm"] = np.nan; t.loc[i, "p_holm"] = holm(t.loc[i, "p"])
        t["delta"] = t.delta.map("{:+.3f}".format); t["p"] = t.p.map("{:.4f}".format)
        print("\n==== E7 tests (one-sided; Holm across models for H13 AUROC) ====\n" + t.to_string(index=False))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--B", type=int, default=2000); main(ap.parse_args().B)
E7A
cat > $PROJ/src/coalrag/experiments/e8_augment.py <<'E8A'
"""E8 corpus augmentation with quantity and topic similarity controlled (professor point 2; pre-registered H15, D82).
Candidate documents: UNSC-CKG v1.2 records outside Choi et al.'s 581 documents, dated before 2013 (every query is from
2013 on), with all five permanent-member votes recorded. Mode: unanimous (all five favour) vs dissent-bearing (any against
or abstention). Topic: similar (the K candidates of that mode nearest to the query) vs random (K drawn uniformly, 3 seeds).
Quantity: K in {100, 400}. All similarities use one text space (CKG texts, bge-small) for every document, so arms differ
only in which documents are added.
  Base F (outcome-filtered): pool = Choi's adopted documents earlier than the query; queries = the non-adopted drafts.
  Base U (unfiltered):       pool = all Choi documents earlier than the query; queries = split, vetoed and failed drafts.
Metrics (exact five-vote configuration): Sup = any match in the pool; bge R@1 / R@10; stratified (top-50) R@10;
m50 = matches in the bge top-50. Paired bootstrap over queries against the un-augmented base."""
import os, zlib
os.environ.setdefault("CKG_VERSION", "v1_2")
from pathlib import Path
import numpy as np, pandas as pd
from coalrag.data.configB import load, match_vec
from coalrag.retrieval.configA import ConfigA

STORE = Path(os.environ["PROJ"]) / "results" / "store"
Kdf, T, TOK, V, H, EMB = load(partial_veto_coding=True, with_emb=True)
E = EMB["bge-small"]; rid = Kdf.res_id.tolist(); pos = {r: i for i, r in enumerate(rid)}
dates = Kdf.date.values; REG = Kdf.regime.values
cfg = ConfigA(); A = [pos[r["res_id"]] for r in cfg.A if r["res_id"] in pos]; N = [pos[r["res_id"]] for r in cfg.N if r["res_id"] in pos]
choi = set(A) | set(N); complete = lambda i: bool(((V[i] >= 1) & (V[i] <= 3)).all())
cand = np.array([i for i in range(len(rid)) if i not in choi and dates[i] < np.datetime64("2013-01-01") and complete(i)])
MODE = {"unanimous": cand[(V[cand] == 1).all(1)], "dissent": cand[~(V[cand] == 1).all(1)]}
print(f"candidates: {len(cand)} (unanimous {len(MODE['unanimous'])}, dissent-bearing {len(MODE['dissent'])}) | Choi docs mapped {len(choi)}")
KS, SEEDS = [100, 400], [0, 1, 2]


def strat(order, Vp, k=10):
    seen, out = set(), []
    for j in order[:50]:
        key = tuple(Vp[j])
        if key not in seen:
            seen.add(key); out.append(j)
        if len(out) == k: break
    return np.array(out, dtype=int)


def measure(q, pool):
    pool = np.asarray(pool, dtype=int); h, _ = match_vec(V[pool], V[q], 0, "answer")
    s = E[pool] @ E[q]; o = np.argsort(-s, kind="stable"); st = strat(o, V[pool])
    return dict(sup=bool(h.any()), r1=bool(h[o[:1]].any()), r10=bool(h[o[:10]].any()), s_r10=bool(h[st].any()), m50=int(h[o[:50]].sum()), n_pool=len(pool))


rows = []
for base, queries, poolsrc in [("F", N, A), ("U", sorted(choi), sorted(choi))]:
    for q in queries:
        if not complete(q) or (base == "U" and REG[q] not in ("split", "vetoed", "failed")): continue
        bp = [j for j in poolsrc if dates[j] < dates[q]]
        if len(bp) < 10: continue
        rows.append(dict(base=base, qid=rid[q], regime=REG[q], arm="none", K=0, mode="", topic="", seed=-1, **measure(q, bp)))
        for mode, C in MODE.items():
            sims = E[C] @ E[q]
            for k in KS:
                k_ = min(k, len(C))
                rows.append(dict(base=base, qid=rid[q], regime=REG[q], arm=f"{mode}-similar-{k}", K=k, mode=mode, topic="similar", seed=-1,
                                 **measure(q, bp + C[np.argsort(-sims, kind="stable")[:k_]].tolist())))
                for sd in SEEDS:
                    rng = np.random.default_rng(zlib.crc32(f"{rid[q]}|{mode}|{k}|{sd}".encode()))
                    rows.append(dict(base=base, qid=rid[q], regime=REG[q], arm=f"{mode}-random-{k}", K=k, mode=mode, topic="random", seed=sd,
                                     **measure(q, bp + rng.choice(C, k_, replace=False).tolist())))
df = pd.DataFrame(rows); df.to_parquet(STORE / "e8_augment.parquet", index=False)
q = df.groupby(["base", "qid", "regime", "arm"], as_index=False)[["sup", "r1", "r10", "s_r10", "m50"]].mean()  # average random seeds per query
rng = np.random.default_rng(0)


def delta(sub, arm, col, B=5000):
    a = sub[sub.arm == arm].set_index("qid")[col]; b = sub[sub.arm == "none"].set_index("qid")[col]; d = (a - b).dropna().values
    bs = d[rng.integers(0, len(d), (B, len(d)))].mean(1)
    return f"{100 * d.mean():+5.1f} [{100 * np.percentile(bs, 2.5):+5.1f},{100 * np.percentile(bs, 97.5):+5.1f}]"


ARMS = ["none"] + [f"{m}-{t}-{k}" for m in MODE for t in ("similar", "random") for k in KS]
for base, lab, regs in [("F", "OUTCOME-FILTERED POOL (Choi adopted only) | non-adopted queries", ["vetoed", "failed"]),
                        ("U", "UNFILTERED POOL (all Choi documents) | contested queries", ["split", "vetoed", "failed"])]:
    sub = q[(q.base == base) & q.regime.isin(regs)]
    print(f"\n==== {lab} | n queries = {sub[sub.arm == 'none'].qid.nunique()} | %, change vs no augmentation [95% CI] ====")
    out = []
    for arm in ARMS:
        s = sub[sub.arm == arm]
        r = dict(arm=arm, Sup=100 * s.sup.mean(), bge_R10=100 * s.r10.mean(), strat_R10=100 * s.s_r10.mean(), m50=s.m50.mean())
        if arm != "none": r.update(dSup=delta(sub, arm, "sup"), dbge_R10=delta(sub, arm, "r10"), dstrat_R10=delta(sub, arm, "s_r10"))
        out.append(r)
    with pd.option_context("display.width", 220): print(pd.DataFrame(out).set_index("arm").round(1).fillna("").to_string())
    for reg in regs:
        s = sub[sub.regime == reg]
        print(f"  {reg:8s} n={s[s.arm == 'none'].qid.nunique():3d} | dissent-similar-400: dSup {delta(s, 'dissent-similar-400', 'sup')} dbge_R10 {delta(s, 'dissent-similar-400', 'r10')}"
              f" | unanimous-similar-400: dbge_R10 {delta(s, 'unanimous-similar-400', 'r10')} dstrat_R10 {delta(s, 'unanimous-similar-400', 's_r10')}")
E8A
cat > $PROJ/configs/gpuq3.sh <<'GPUQ3'
#!/usr/bin/env bash
# Two-GPU queue v3 (D73). Single serving standard for every model:
#   vLLM V1 engine, --generation-config vllm (neutral sampling: no model-default repetition penalty),
#   chunked prefill with --max-num-batched-tokens 2048 (bounds the prompt log-prob tensor), --max-model-len 8192,
#   and a preflight that scores 8 near-maximum-length prompts concurrently before any run.
#   bash gpuq3.sh stop    stop all lanes (v1-v3), LLM clients and this user's servers on GPUs 7 and 9
#   bash gpuq3.sh diag    coverage, errors, prompt lengths, Llama format, template audit
#   bash gpuq3.sh lane9   GPU 9 :8001  32B main (pre-registered e4 runner) -> 32B all-regime -> 32B wave 2
#   bash gpuq3.sh lane7   GPU 7 :8007  Mistral-24B-2501 main + F,M -> Qwen2.5-7B main + F,M -> Qwen3-8B thinking off/on
#   bash gpuq3.sh tp2     GPUs 7+9 :8007  waits for both lanes, then Llama-3.3-70B-FP8 (reduced set + F)
#   bash gpuq3.sh lane7w  GPU 7 :8007  second 32B server for the 32B wave 2 (D77)
#   bash gpuq3.sh lane6   GPU 6 :8006  E7 selection experiment on Mistral, 7B, 32B; then releases GPU 6 (D81)
#   bash gpuq3.sh tp2b    waits for lane7w and the all-regime client, retries all-regime, then Llama (D77)
set -u
LANE=${1:?usage: gpuq3.sh stop|diag|lane9|lane7|tp2|lane7w|tp2b|lane6}
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src CUDA_DEVICE_ORDER=PCI_BUS_ID
L=$PROJ/logs/gpuq3.log
say() { echo "[$(date '+%m-%d %H:%M:%S')] [$LANE] $*" | tee -a $L; }
served() { curl -s -m 10 127.0.0.1:$1/v1/models | python -c "import sys,json; print(json.load(sys.stdin)['data'][0]['id'])" 2>/dev/null; }
cov() { python -m coalrag.tools.diag 2>/dev/null | grep "^e4_$1_$2.jsonl" | cut -d'|' -f1-3; }
free_gpu() {  # this user's processes on the listed GPUs, plus their 'vllm serve' parent
  for g in ${1//,/ }; do
    for p in $(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader); do
      [ "$(ps -o user= -p $p 2>/dev/null | tr -d ' ')" = "$USER" ] || continue
      pp=$(ps -o ppid= -p $p | tr -d ' '); ps -o cmd= -p $pp | grep -q "vllm serve" && kill $pp; kill $p 2>/dev/null
    done
  done; sleep 30
}
stop_port() { pkill -u $USER -f "vllm serve.*--port $1( |$)"; sleep 5; }
serve_chain() {  # $1 GPUs, $2 port, $3 checkpoint, $4 served name, then one quoted string of vllm args per configuration
  local G=$1 P=$2 M=$3 N=$4; shift 4
  [ -f "$M/config.json" ] || { say "SKIP $N: $M missing"; return 1; }
  for cfg in "$@"; do
    stop_port $P; free_gpu $G
    conda activate crag-vllm
    VLLM_USE_V1=1 CUDA_VISIBLE_DEVICES=$G nohup vllm serve $M --served-model-name $N --host 127.0.0.1 --port $P --seed 0 \
      --generation-config vllm --max-model-len 8192 --max-num-batched-tokens 2048 --max-num-seqs 16 $cfg \
      > $PROJ/logs/vllm_${N}_$P.log 2>&1 &
    local pid=$! ok=0; conda activate crag
    for i in $(seq 1 360); do
      [ "$(served $P)" = "$N" ] && { ok=1; break; }; kill -0 $pid 2>/dev/null || break; sleep 5
    done
    if [ $ok = 1 ]; then
      local pf; pf=$(python -W ignore -m coalrag.tools.preflight $N http://127.0.0.1:$P/v1 8192 2>&1 | tail -1)
      say "$N on GPU $G :$P [$cfg] | $(grep -h 'KV cache size' $PROJ/logs/vllm_${N}_$P.log | tail -1 | sed 's/.*INFO[^]]*] //') | $pf"
      echo "$pf" | grep -q " 8/8 " && return 0
      say "  server log tail: $(grep -hE 'Error|error' $PROJ/logs/vllm_${N}_$P.log | tail -1 | cut -c1-200)"
    else
      say "$N failed to start [$cfg]: $(grep -hE 'Error|error' $PROJ/logs/vllm_${N}_$P.log | tail -1 | cut -c1-200)"
    fi
  done
  stop_port $P; say "SERVE FAILED $N (all configurations)"; return 1
}
e4main() {  # $1 port, $2 served name, $3 concurrency
  say "start $2 main (pre-registered e4 runner)"
  for pass in 1 2; do python -W ignore -m coalrag.experiments.e4_llm --served $2 --base http://127.0.0.1:$1/v1 --tag main --conc $3 >> $PROJ/logs/e4_$2_main.log 2>&1; done
  say "end   $2 main | $(cov $2 main)"
}
e5() {  # $1 port, $2 served name, $3 tag, rest = e5_wave2 args; two passes so transient errors are retried
  local P=$1 N=$2 T=$3; shift 3; say "start $N $T $*"
  for pass in 1 2; do python -W ignore -m coalrag.experiments.e5_wave2 --served $N --base http://127.0.0.1:$P/v1 --tag $T "$@" >> $PROJ/logs/e5_$N.log 2>&1; done
  say "end   $N $T | $(cov $N $T)"
}

e7() {  # $1 port, $2 served name: E7 selection experiment (D81), two passes
  say "start $2 e7"
  for pass in 1 2; do python -W ignore -m coalrag.experiments.e7_select --served $2 --base http://127.0.0.1:$1/v1 --conc 16 >> $PROJ/logs/e7_$2.log 2>&1; done
  say "end   $2 e7 | $(grep -E '^wall' $PROJ/logs/e7_$2.log | tail -1)"
}
lane6() {  # D81: borrowed GPU 6 (port 8006) for E7 on Mistral-24B, Qwen2.5-7B, Qwen2.5-32B; releases GPU 6 at the end
  local G=6 P=8006
  serve_chain $G $P $HOME/models/Mistral-Small-24B-Instruct-2501-FP8-dynamic mistral-small-24b-2501-fp8 \
    "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager" && e7 $P mistral-small-24b-2501-fp8
  serve_chain $G $P /mnt/nvme01/huggingface/models/Qwen/Qwen2.5-7B-Instruct qwen2.5-7b \
    "--gpu-memory-utilization 0.80" "--gpu-memory-utilization 0.75 --enforce-eager" && e7 $P qwen2.5-7b
  serve_chain $G $P $HOME/models/Qwen2.5-32B-Instruct-GPTQ-Int8 qwen2.5-32b-gptq-int8 \
    "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager" && e7 $P qwen2.5-32b-gptq-int8
  stop_port $P; free_gpu $G; say "GPU 6 released"
}
stop() {
  pkill -u $USER -f "gpuq[23]?\.sh (lane|tp2)"; pkill -u $USER -f "queue_wave2.sh"
  pkill -u $USER -f "coalrag.experiments.e[457]"; pkill -u $USER -f "coalrag.tools.preflight"; sleep 3
  stop_port 8001; stop_port 8006; stop_port 8007; free_gpu 6,7,9
  for g in 7 9; do echo "GPU $g in use: $(nvidia-smi -i $g --query-gpu=memory.used --format=csv,noheader)"; done
}
diag() { python -W ignore -m coalrag.tools.diag; }
lane9() {
  local G=9 P=8001 N=qwen2.5-32b-gptq-int8
  serve_chain $G $P $HOME/models/Qwen2.5-32B-Instruct-GPTQ-Int8 $N \
    "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager" || return 1
  e4main $P $N 12
  e5 $P $N allreg --conds AR --queries adopted --conc 16
  e5 $P $N wave2 --conds wave2 --conc 12
}
lane7() {
  local G=7 P=8007 N=mistral-small-24b-2501-fp8
  if serve_chain $G $P $HOME/models/Mistral-Small-24B-Instruct-2501-FP8-dynamic $N \
       "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager"; then
    e5 $P $N main --conds main --conc 16
    e5 $P $N wave2 --conds F,M --conc 16
  fi
  N=qwen2.5-7b
  if serve_chain $G $P /mnt/nvme01/huggingface/models/Qwen/Qwen2.5-7B-Instruct $N \
       "--gpu-memory-utilization 0.80" "--gpu-memory-utilization 0.75 --enforce-eager"; then
    e5 $P $N main --conds main --conc 32
    e5 $P $N wave2 --conds F,M --conc 32
  fi
  N=qwen3-8b
  if serve_chain $G $P $HOME/models/Qwen3-8B $N \
       "--gpu-memory-utilization 0.80" "--gpu-memory-utilization 0.75 --enforce-eager"; then
    e5 $P $N think-off --conds THINK --think off --conc 32
    e5 $P $N think-on --conds THINK --think on --budget 1024 --conc 32
  fi
}
llama() {  # Llama-3.3-70B-FP8 (ModelOpt) across GPUs 7+9, reduced condition set + F
  local G=7,9 P=8007 N=llama-3.3-70b-fp8 M=/mnt/nvme01/huggingface/models/MetaAI/Llama-3.3-70B-Instruct-FP8
  [ -f $M/hf_quant_config.json ] || { say "SKIP $N: no hf_quant_config.json"; return 1; }
  stop_port 8001; stop_port 8007
  serve_chain $G $P $M $N \
    "--tensor-parallel-size 2 --quantization modelopt --gpu-memory-utilization 0.88" \
    "--tensor-parallel-size 2 --quantization modelopt --gpu-memory-utilization 0.85 --enforce-eager" || return 1
  e5 $P $N main --conds B0-choi,B0-std,CF-LTorig,D-bge-coal,D-oracle-coal,D-random-coal,D-strat4-coal --conc 12
  e5 $P $N wave2 --conds F --conc 12
}
tp2() {
  say "waiting for lane9 and lane7 to finish and for every LLM client to exit"
  until grep -q "\[lane9\] lane9 done" $L && grep -q "\[lane7\] lane7 done" $L && ! pgrep -u $USER -f "coalrag.experiments.e[45]" >/dev/null; do sleep 300; done
  llama
}
lane7w() {  # D77: second 32B server on GPU 7 takes the 32B wave 2 while GPU 9 finishes the all-regime run
  local G=7 P=8007 N=qwen2.5-32b-gptq-int8
  serve_chain $G $P $HOME/models/Qwen2.5-32B-Instruct-GPTQ-Int8 $N \
    "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager" || return 1
  e5 $P $N wave2 --conds wave2 --conc 12
}
tp2b() {  # waits for lane7w and for no LLM client in two checks 5 minutes apart; retries the all-regime run; then Llama
  say "waiting for lane7w to finish and for every LLM client (including the all-regime run on :8001) to exit"
  local quiet=0
  until [ $quiet -ge 2 ]; do
    sleep 300
    if grep -q "\[lane7w\] lane7w done" $L && ! pgrep -u $USER -f "coalrag.experiments.e[45]" >/dev/null; then quiet=$((quiet+1)); else quiet=0; fi
  done
  [ "$(served 8001)" = "qwen2.5-32b-gptq-int8" ] && e5 8001 qwen2.5-32b-gptq-int8 allreg --conds AR --queries adopted --conc 16
  llama
}
case $LANE in
  stop|diag) $LANE ;;
  lane9|lane7|tp2|lane7w|tp2b|lane6) trap 'say "$LANE done"' EXIT; say "started"; $LANE ;;
  *) echo "unknown lane $LANE"; exit 2 ;;
esac
GPUQ3
chmod +x $PROJ/configs/gpuq3.sh
grep -q "^H13 " $PROJ/configs/prereg.md || cat >> $PROJ/configs/prereg.md <<'PREREG'

## Selection and augmentation (added 2026-10-03, before any E7 or E8 output; analyses: analysis/e7_analysis.py, experiments/e8_augment.py)
H13 Selection: aggregating the four single-precedent predictions with the model's own choice of the closest precedent (S-llmsel; texts only, no votes) raises AUROC(P against) over showing the four stratified precedents together (D-strat4-coal). One-sided, Holm across models. Secondary metric: macro-F1 after Batch Calibration.
H14 Bound: taking the single-precedent prediction of the stratified slot whose five-vote configuration equals the draft's (S-perfect; uses the label, so a bound and not a method) exceeds D-strat4-coal in AUROC(P against). The oracle gap is reported as selection + coverage.
H15a Outcome filter: in Choi's adopted-only pool, adding dissent-bearing documents raises Sup and bge R@10 for non-adopted drafts; adding unanimous documents changes neither.
H15b Topic: at equal K, topically similar dissent-bearing documents raise bge R@10 more than random ones.
H15c Dilution: in the unfiltered pool, adding K topically similar unanimous documents lowers bge R@10 on contested drafts, while stratified R@10 does not fall significantly.
PREREG
grep -q "^- D80" $PROJ/configs/DECISIONS.md || cat >> $PROJ/configs/DECISIONS.md <<'DEC'
- D80 Positioning (independence from Choi et al.): the paper is built on our dataset (UNSC-CKG v1.2 supplies every vote), our evaluation protocol (option-likelihood scoring, controlled evidence views, exact-configuration retrieval metrics, calibrated LLM metrics, non-LLM baselines) and our findings. Choi et al.'s released documents are used as the text source for 581 drafts and cited as data. Their pipeline appears as one reimplemented prior-pipeline row (CF-LTorig) in the main table; the other CF variants and the replication notes go to an appendix, described neutrally. No sentence frames the paper as a correction of that work. Cited in the third person (double-blind).
- D81 E7 selection experiment on borrowed GPU 6 (Mistral-24B, Qwen2.5-7B, Qwen2.5-32B), pre-registered as H13-H14 before any output; aggregation rules fixed in e7_analysis.py; nothing tuned. Motivation: H5c failed and the evidence factorial shows vote copying, so the open question is whether the oracle gap is selection or coverage.
- D82 Professor point 2 is answered by E8 (CPU; CKG documents outside Choi's set; quantity K in {100, 400}; topic similar vs random; mode unanimous vs dissent-bearing; outcome-filtered and unfiltered pools), pre-registered as H15. Point 5 (second behavioural domain) is deferred to the follow-up paper and stated as a limitation: the Art. 27(3) outcome filter has no General Assembly counterpart, so a GA replication would test only the crowding half of the claim, and it needs a separate vote-data pipeline that cannot be validated before the freeze.
DEC
python -m py_compile src/coalrag/experiments/e7_select.py src/coalrag/analysis/e7_analysis.py src/coalrag/experiments/e8_augment.py && bash -n configs/gpuq3.sh
git add -A && git -c user.name=becky1 -c user.email=becky1@andlab commit -qm "Pre-register H13-H15 (E7 selection, E8 augmentation); D80-D82" && git log -1 --format="PREREG commit %h %ad" || echo "nothing new to commit"
