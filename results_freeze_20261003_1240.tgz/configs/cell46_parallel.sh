#!/usr/bin/env bash
# Cell 46 bundle (2026-10-03): gpuq3.sh with lane7w/tp2b (D77), cross-model summary with pre-registered tests (D76),
# run_analysis.sh. Writes files and commits only; starts nothing. Safe to re-run.
set -e
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src
cd $PROJ
cat > $PROJ/configs/gpuq3.sh <<'GPUQ3'
#!/usr/bin/env bash
# Two-GPU queue v3 (D73). Single serving standard for every model:
#   vLLM V1 engine, --generation-config vllm (neutral sampling: no model-default repetition penalty),
#   chunked prefill with --max-num-batched-tokens 2048 (bounds the prompt log-prob tensor), --max-model-len 8192,
#   and a preflight that scores 8 near-maximum-length prompts concurrently before any run.
#   bash gpuq3.sh stop    stop all lanes (v1-v3), LLM clients and this user's servers on GPUs 7 and 9
#   bash gpuq3.sh diag    coverage, errors, prompt lengths, Llama format, template audit
#   bash gpuq3.sh lane9   GPU 9 :8001  32B main (pre-registered e4 runner) -> 32B all-regime -> 32B wave 2
#   bash gpuq3.sh lane7   GPU 7 :8007  Mistral-24B-2501 main + F,M -> Qwen2.5-7B main + F,M -> Qwen3-8B thinking off/on
#   bash gpuq3.sh tp2     GPUs 7+9 :8007  waits for both lanes, then Llama-3.3-70B-FP8 (reduced set + F)
#   bash gpuq3.sh lane7w  GPU 7 :8007  second 32B server for the 32B wave 2 (D77)
#   bash gpuq3.sh tp2b    waits for lane7w and the all-regime client, retries all-regime, then Llama (D77)
set -u
LANE=${1:?usage: gpuq3.sh stop|diag|lane9|lane7|tp2|lane7w|tp2b}
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src CUDA_DEVICE_ORDER=PCI_BUS_ID
L=$PROJ/logs/gpuq3.log
say() { echo "[$(date '+%m-%d %H:%M:%S')] [$LANE] $*" | tee -a $L; }
served() { curl -s -m 10 127.0.0.1:$1/v1/models | python -c "import sys,json; print(json.load(sys.stdin)['data'][0]['id'])" 2>/dev/null; }
cov() { python -m coalrag.tools.diag 2>/dev/null | grep "^e4_$1_$2.jsonl" | cut -d'|' -f1-3; }
free_gpu() {  # this user's processes on the listed GPUs, plus their 'vllm serve' parent
  for g in ${1//,/ }; do
    for p in $(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader); do
      [ "$(ps -o user= -p $p 2>/dev/null | tr -d ' ')" = "$USER" ] || continue
      pp=$(ps -o ppid= -p $p | tr -d ' '); ps -o cmd= -p $pp | grep -q "vllm serve" && kill $pp; kill $p 2>/dev/null
    done
  done; sleep 30
}
stop_port() { pkill -u $USER -f "vllm serve.*--port $1( |$)"; sleep 5; }
serve_chain() {  # $1 GPUs, $2 port, $3 checkpoint, $4 served name, then one quoted string of vllm args per configuration
  local G=$1 P=$2 M=$3 N=$4; shift 4
  [ -f "$M/config.json" ] || { say "SKIP $N: $M missing"; return 1; }
  for cfg in "$@"; do
    stop_port $P; free_gpu $G
    conda activate crag-vllm
    VLLM_USE_V1=1 CUDA_VISIBLE_DEVICES=$G nohup vllm serve $M --served-model-name $N --host 127.0.0.1 --port $P --seed 0 \
      --generation-config vllm --max-model-len 8192 --max-num-batched-tokens 2048 --max-num-seqs 16 $cfg \
      > $PROJ/logs/vllm_${N}_$P.log 2>&1 &
    local pid=$! ok=0; conda activate crag
    for i in $(seq 1 360); do
      [ "$(served $P)" = "$N" ] && { ok=1; break; }; kill -0 $pid 2>/dev/null || break; sleep 5
    done
    if [ $ok = 1 ]; then
      local pf; pf=$(python -W ignore -m coalrag.tools.preflight $N http://127.0.0.1:$P/v1 8192 2>&1 | tail -1)
      say "$N on GPU $G :$P [$cfg] | $(grep -h 'KV cache size' $PROJ/logs/vllm_${N}_$P.log | tail -1 | sed 's/.*INFO[^]]*] //') | $pf"
      echo "$pf" | grep -q " 8/8 " && return 0
      say "  server log tail: $(grep -hE 'Error|error' $PROJ/logs/vllm_${N}_$P.log | tail -1 | cut -c1-200)"
    else
      say "$N failed to start [$cfg]: $(grep -hE 'Error|error' $PROJ/logs/vllm_${N}_$P.log | tail -1 | cut -c1-200)"
    fi
  done
  stop_port $P; say "SERVE FAILED $N (all configurations)"; return 1
}
e4main() {  # $1 port, $2 served name, $3 concurrency
  say "start $2 main (pre-registered e4 runner)"
  for pass in 1 2; do python -W ignore -m coalrag.experiments.e4_llm --served $2 --base http://127.0.0.1:$1/v1 --tag main --conc $3 >> $PROJ/logs/e4_$2_main.log 2>&1; done
  say "end   $2 main | $(cov $2 main)"
}
e5() {  # $1 port, $2 served name, $3 tag, rest = e5_wave2 args; two passes so transient errors are retried
  local P=$1 N=$2 T=$3; shift 3; say "start $N $T $*"
  for pass in 1 2; do python -W ignore -m coalrag.experiments.e5_wave2 --served $N --base http://127.0.0.1:$P/v1 --tag $T "$@" >> $PROJ/logs/e5_$N.log 2>&1; done
  say "end   $N $T | $(cov $N $T)"
}

stop() {
  pkill -u $USER -f "gpuq[23]?\.sh (lane|tp2)"; pkill -u $USER -f "queue_wave2.sh"
  pkill -u $USER -f "coalrag.experiments.e[45]"; pkill -u $USER -f "coalrag.tools.preflight"; sleep 3
  stop_port 8001; stop_port 8007; free_gpu 7,9
  for g in 7 9; do echo "GPU $g in use: $(nvidia-smi -i $g --query-gpu=memory.used --format=csv,noheader)"; done
}
diag() { python -W ignore -m coalrag.tools.diag; }
lane9() {
  local G=9 P=8001 N=qwen2.5-32b-gptq-int8
  serve_chain $G $P $HOME/models/Qwen2.5-32B-Instruct-GPTQ-Int8 $N \
    "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager" || return 1
  e4main $P $N 12
  e5 $P $N allreg --conds AR --queries adopted --conc 16
  e5 $P $N wave2 --conds wave2 --conc 12
}
lane7() {
  local G=7 P=8007 N=mistral-small-24b-2501-fp8
  if serve_chain $G $P $HOME/models/Mistral-Small-24B-Instruct-2501-FP8-dynamic $N \
       "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager"; then
    e5 $P $N main --conds main --conc 16
    e5 $P $N wave2 --conds F,M --conc 16
  fi
  N=qwen2.5-7b
  if serve_chain $G $P /mnt/nvme01/huggingface/models/Qwen/Qwen2.5-7B-Instruct $N \
       "--gpu-memory-utilization 0.80" "--gpu-memory-utilization 0.75 --enforce-eager"; then
    e5 $P $N main --conds main --conc 32
    e5 $P $N wave2 --conds F,M --conc 32
  fi
  N=qwen3-8b
  if serve_chain $G $P $HOME/models/Qwen3-8B $N \
       "--gpu-memory-utilization 0.80" "--gpu-memory-utilization 0.75 --enforce-eager"; then
    e5 $P $N think-off --conds THINK --think off --conc 32
    e5 $P $N think-on --conds THINK --think on --budget 1024 --conc 32
  fi
}
llama() {  # Llama-3.3-70B-FP8 (ModelOpt) across GPUs 7+9, reduced condition set + F
  local G=7,9 P=8007 N=llama-3.3-70b-fp8 M=/mnt/nvme01/huggingface/models/MetaAI/Llama-3.3-70B-Instruct-FP8
  [ -f $M/hf_quant_config.json ] || { say "SKIP $N: no hf_quant_config.json"; return 1; }
  stop_port 8001; stop_port 8007
  serve_chain $G $P $M $N \
    "--tensor-parallel-size 2 --quantization modelopt --gpu-memory-utilization 0.88" \
    "--tensor-parallel-size 2 --quantization modelopt --gpu-memory-utilization 0.85 --enforce-eager" || return 1
  e5 $P $N main --conds B0-choi,B0-std,CF-LTorig,D-bge-coal,D-oracle-coal,D-random-coal,D-strat4-coal --conc 12
  e5 $P $N wave2 --conds F --conc 12
}
tp2() {
  say "waiting for lane9 and lane7 to finish and for every LLM client to exit"
  until grep -q "\[lane9\] lane9 done" $L && grep -q "\[lane7\] lane7 done" $L && ! pgrep -u $USER -f "coalrag.experiments.e[45]" >/dev/null; do sleep 300; done
  llama
}
lane7w() {  # D77: second 32B server on GPU 7 takes the 32B wave 2 while GPU 9 finishes the all-regime run
  local G=7 P=8007 N=qwen2.5-32b-gptq-int8
  serve_chain $G $P $HOME/models/Qwen2.5-32B-Instruct-GPTQ-Int8 $N \
    "--gpu-memory-utilization 0.85" "--gpu-memory-utilization 0.80 --enforce-eager" || return 1
  e5 $P $N wave2 --conds wave2 --conc 12
}
tp2b() {  # waits for lane7w and for no LLM client in two checks 5 minutes apart; retries the all-regime run; then Llama
  say "waiting for lane7w to finish and for every LLM client (including the all-regime run on :8001) to exit"
  local quiet=0
  until [ $quiet -ge 2 ]; do
    sleep 300
    if grep -q "\[lane7w\] lane7w done" $L && ! pgrep -u $USER -f "coalrag.experiments.e[45]" >/dev/null; then quiet=$((quiet+1)); else quiet=0; fi
  done
  [ "$(served 8001)" = "qwen2.5-32b-gptq-int8" ] && e5 8001 qwen2.5-32b-gptq-int8 allreg --conds AR --queries adopted --conc 16
  llama
}
case $LANE in
  stop|diag) $LANE ;;
  lane9|lane7|tp2|lane7w|tp2b) trap 'say "$LANE done"' EXIT; say "started"; $LANE ;;
  *) echo "unknown lane $LANE"; exit 2 ;;
esac
GPUQ3
cat > $PROJ/configs/run_analysis.sh <<'RUNAN'
#!/usr/bin/env bash
# CPU analysis of every completed LLM run (D76). Writes logs/analysis/*.log and one combined ALL_<time>.txt to send back.
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src
A=$PROJ/logs/analysis; mkdir -p $A
for m in qwen2.5-32b-gptq-int8 mistral-small-24b-2501-fp8 qwen2.5-7b llama-3.3-70b-fp8; do
  f=$PROJ/results/store/e4_${m}_main.jsonl; [ -f $f ] || continue
  echo "[$(date +%H:%M)] $m"
  python -W ignore -m coalrag.analysis.e4_metrics $f --cad --B 2000 --by qset > $A/metrics_$m.log 2>&1
  python -W ignore -m coalrag.analysis.e4_hda $f > $A/hda_$m.log 2>&1
  python -W ignore -m coalrag.analysis.e5_analysis $m --B 1000 > $A/e5_$m.log 2>&1
done
[ -f $PROJ/results/store/e4_qwen3-8b_think-on.jsonl ] && python -W ignore -m coalrag.analysis.e5_analysis qwen3-8b --B 1000 > $A/e5_qwen3-8b.log 2>&1
python -W ignore -m coalrag.analysis.summary --B 2000 > $A/summary.log 2>&1
O=$A/ALL_$(date +%m%d_%H%M).txt
for f in $A/summary.log $A/metrics_*.log $A/e5_*.log $A/hda_*.log; do echo "########## $(basename $f)"; cat $f; done > $O
echo "done: $O ($(wc -l < $O) lines)"
RUNAN
cat > $PROJ/src/coalrag/analysis/summary.py <<'SUMM'
"""Cross-model LLM summary (pre-registered H5-H7, D76). For every model with a complete main run:
  table 1: condition x model, macro-F1 after Batch Calibration (BC) / AUROC of P(against) / Yes-rate gap / No-recall
  table 2: pre-registered tests, one-sided resolution-cluster paired bootstrap (B draws), Holm within each model
Writes results/tables/llm_crossmodel.md and results/tables/llm_tests.csv.
Usage: python -m coalrag.analysis.summary [--B 2000] [--models m1,m2]"""
import argparse, os
from pathlib import Path
import numpy as np, pandas as pd
from coalrag.analysis.e4_metrics import metrics, add_cad

PROJ = Path(os.environ["PROJ"]); STORE = PROJ / "results" / "store"; OUT = PROJ / "results" / "tables"; K = ["qid", "nation"]
CONDS = ["B0-choi", "B0-std", "CF-LTorig", "CF-LT", "CF-bge", "CF-CSR3", "D-bge-text", "D-bge-target", "D-bge-coal",
         "D-random-coal", "D-oracle-coal", "D-top4-coal", "D-strat4-target", "D-strat4-coal",
         "D-random-coal+CAD1", "D-oracle-coal+CAD1", "D-strat4-coal+CAD1"]
TESTS = [  # (hypothesis, metric, condition a, condition b): one-sided H1: metric(a) > metric(b)
    ("H5", "aucN", "D-strat4-coal", "B0-std"), ("H5", "aucN", "D-oracle-coal", "B0-std"),
    ("H5", "macroF1_BC", "D-oracle-coal", "D-random-coal"),
    ("H6", "macroF1_BC", "D-strat4-coal", "B0-std"), ("H6", "macroF1_BC", "D-oracle-coal", "B0-std"),
    ("H7", "macroF1_BC", "D-strat4-coal+CAD1", "D-strat4-coal"), ("H7", "macroF1_BC", "D-oracle-coal+CAD1", "D-oracle-coal"),
    ("H7-control", "macroF1_BC", "D-random-coal+CAD1", "D-random-coal")]


def load(m):
    p = STORE / f"e4_{m}_main.jsonl"
    d = pd.read_json(p, lines=True); d = d[d.error.isna() & d.true.isin(["Y", "N", "A"])].drop_duplicates(K + ["cond"], keep="last")
    d = add_cad(d, "B0-std")
    keys = set.intersection(*[set(zip(g.qid, g.nation)) for _, g in d.groupby("cond")])
    return d[[k in keys for k in zip(d.qid, d.nation)]].sort_values(["cond"] + K).reset_index(drop=True), len(keys)


def holm(p):
    p = np.asarray(p, float); o = np.argsort(p); adj = np.empty_like(p); run = 0.0
    for r, i in enumerate(o):
        run = max(run, min(1.0, (len(p) - r) * p[i])); adj[i] = run
    return adj


def main(B, models):
    models = models or sorted(p.name[3:-11] for p in STORE.glob("e4_*_main.jsonl"))
    OUT.mkdir(parents=True, exist_ok=True); T1, T2 = [], []
    for m in models:
        d, nk = load(m); g = {c: x for c, x in d.groupby("cond")}
        qids = np.array(sorted(d.qid.unique())); rng = np.random.default_rng(0)
        pos = {c: {q: np.where(g[c].qid.values == q)[0] for q in qids} for c in g}
        pt = {c: metrics(g[c].true.values, g[c][["pY", "pN", "pA"]].values.astype(float)) for c in g}
        for c in CONDS:
            if c in pt: T1.append(dict(model=m, cond=c, **{k: pt[c][k] for k in ("macroF1", "macroF1_BC", "aucN", "yes_gap", "no_recall", "acc")}))
        need = sorted({c for _, _, a, b in TESTS for c in (a, b) if c in g}); boot = {c: [] for c in need}
        for _ in range(B):
            s = rng.choice(qids, len(qids))
            for c in need:
                ix = np.concatenate([pos[c][q] for q in s])
                boot[c].append(metrics(g[c].true.values[ix], g[c][["pY", "pN", "pA"]].values[ix].astype(float)))
        rows = []
        for h, k, a, b in TESTS:
            if a not in g or b not in g: continue
            db = np.array([x[k] - y[k] for x, y in zip(boot[a], boot[b])], float); db = db[~np.isnan(db)]
            rows.append(dict(model=m, hyp=h, metric=k, a=a, b=b, delta=pt[a][k] - pt[b][k], lo=np.percentile(db, 2.5), hi=np.percentile(db, 97.5),
                             p_one_sided=(1 + np.sum(db <= 0)) / (len(db) + 1)))
        fam = [i for i, r in enumerate(rows) if r["hyp"] != "H7-control"]
        adj = holm([rows[i]["p_one_sided"] for i in fam])
        for i, r in enumerate(rows): r["p_holm"] = adj[fam.index(i)] if i in fam else np.nan
        T2 += rows
        bc_up = sum(pt[c]["macroF1_BC"] >= pt[c]["macroF1"] for c in g if "+" not in c)
        print(f"{m}: {nk} (draft, nation) pairs in every condition | H6 part 1: BC >= raw macro-F1 in {bc_up}/{sum('+' not in c for c in g)} conditions")
    t1, t2 = pd.DataFrame(T1), pd.DataFrame(T2)
    cell = lambda r: f"{r.macroF1_BC:.3f} / {r.aucN:.3f} / {r.yes_gap:+.2f} / {r.no_recall:.2f}"
    tab = t1.assign(v=t1.apply(cell, axis=1)).pivot(index="cond", columns="model", values="v").reindex([c for c in CONDS if c in set(t1.cond)])
    t2.to_csv(OUT / "llm_tests.csv", index=False); t1.to_csv(OUT / "llm_conditions.csv", index=False)
    fmt = t2.assign(delta=t2.delta.map("{:+.3f}".format), ci=t2.apply(lambda r: f"[{r.lo:+.3f}, {r.hi:+.3f}]", axis=1),
                    p=t2.p_one_sided.map("{:.4f}".format), p_holm=t2.p_holm.map(lambda x: "" if pd.isna(x) else f"{x:.4f}"))[
        ["model", "hyp", "metric", "a", "b", "delta", "ci", "p", "p_holm"]]
    def mdtab(x, index=True):
        try: return x.to_markdown(index=index)
        except ImportError: return "```\n" + x.to_string(index=index) + "\n```"
    md = ["# LLM results across models", "", "Cell = macro-F1 after Batch Calibration / AUROC of P(against) / Yes-rate gap / No-recall", "",
          mdtab(tab), "", "## Pre-registered tests (one-sided, resolution-cluster bootstrap; Holm within model, H7-control excluded)", "",
          mdtab(fmt, False)]
    (OUT / "llm_crossmodel.md").write_text("\n".join(md))
    with pd.option_context("display.width", 260, "display.max_columns", 20, "display.max_colwidth", 40):
        print("\n==== Table 1: macro-F1(BC) / AUROC(N) / Yes-gap / No-recall ====\n" + tab.to_string())
        print("\n==== Table 2: pre-registered tests ====\n" + fmt.to_string(index=False))
    print(f"\nwritten: {OUT / 'llm_crossmodel.md'}, llm_tests.csv, llm_conditions.csv")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--B", type=int, default=2000); ap.add_argument("--models", default="")
    a = ap.parse_args(); main(a.B, [x for x in a.models.split(",") if x])
SUMM
chmod +x $PROJ/configs/gpuq3.sh $PROJ/configs/run_analysis.sh
grep -q "^- D76" $PROJ/configs/DECISIONS.md || cat >> $PROJ/configs/DECISIONS.md <<'DEC'
- D76 Paper tables come from analysis/summary.py: Table 1 = condition x model (macro-F1 after Batch Calibration, AUROC of P(against), Yes-rate gap, No-recall); Table 2 = the pre-registered H5-H7 contrasts as one-sided resolution-cluster paired bootstraps (B = 2000) with Holm correction within each model; the H7 random-evidence control is reported but excluded from the Holm family.
- D77 Compute re-plan (3 Oct, 11:00 KST): GPU 7 idle since 07:42 KST while the 32B all-regime run on GPU 9 proceeds at about 14 tasks/min (15.5k-token KV cache; requests that need prompt log-probabilities bypass the prefix cache, so each option re-reads the full prompt). A second 32B server on GPU 7 runs the 32B wave 2 (lane7w); lane9's own wave-2 step is cancelled; Llama-70B (tp2b) starts after both finish, retrying any all-regime errors first. Same checkpoint and serving standard (D73) on both GPUs.
DEC
python -m py_compile src/coalrag/analysis/summary.py && bash -n configs/gpuq3.sh && bash -n configs/run_analysis.sh
git add -A && git -c user.name=becky1 -c user.email=becky1@andlab commit -qm "D76-D77: cross-model summary, lane7w/tp2b, run_analysis" && git log -1 --format="commit %h %ad" || echo "nothing new to commit"
