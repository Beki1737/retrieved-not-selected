# Pre-registration (committed before analysing the 32B outputs; after the 7B development pilot)
Primary match notion: exact five-vote configuration (strict earlier, undefined pairs reported under lower and upper bounds).
Primary LLM metrics: macro-F1, macro-F1 after Batch Calibration, AUROC of P(against), Yes-rate gap; resolution-cluster bootstrap; Holm across H5-H7.
H1 Crowding: for mode-blind retrievers on vetoed/failed queries, the largest failure share lies between R@50 and R@10.
H2 Composition law: mode-blind retrievers' R@k is predicted by top-50 composition (hypergeometric); entropy and stratified rerankers exceed it.
H3 Crossover: entropy reranking raises R@1 on split/vetoed and lowers it on consensus, also under symmetric text (Config A').
H4 Stratification: strat-bge R@3 >= bge in every regime and not below CSR3 on consensus, split and failed.
H5 Evidence use: D-strat4-coal and D-oracle-coal exceed B0-std in AUROC(P against); D-oracle-coal exceeds D-random-coal in macro-F1 (BC).
H6 Prior: Batch Calibration raises macro-F1 in all conditions; the evidence advantage of H5 persists after calibration.
H7 Amplification: CAD (alpha=1, fixed a priori) and AdaCAD raise macro-F1 (BC) for relevant evidence but not for D-random-coal.
Tuning rule: any tuned parameter is fit on 2013-2018 drafts and evaluated on 2019-2024; all conditions are reported.

## Wave 2 (added 2026-10-02, before any wave-2 output exists; analysis = src/coalrag/analysis/e5_analysis.py)
H8 Causal evidence use: P(true) is higher with the oracle precedent's votes shown than with its text only (F-orc-coal > F-orc-text), and flipping the displayed target vote lowers P(true) (F-orc-flip < F-orc-coal).
H9 Evidence-level affirmative prior: uptake of a displayed 'against' when the truth is favour is smaller than uptake of a displayed 'favour' when the truth is against (uptake measured against the text-only arm).
H10 Coalition inference: the other four members' votes alone raise AUROC(P against) over text only (F-orc-others > F-orc-text).
H11 Robustness: the sign of AUROC(N) for D-strat4-coal minus B0-std holds under every discovered Choi paraphrase and under reversed and shuffled precedent order.
H12 No false-veto cost: on adopted consensus drafts, D-strat4-coal does not significantly raise the false-against rate over B0-std.
Descriptive only: memorization split (M-symbol), k = 2/4/6, Qwen3 thinking on vs off, Mistral-24B-2501 and Qwen2.5-7B replications.

## Selection and augmentation (added 2026-10-03, before any E7 or E8 output; analyses: analysis/e7_analysis.py, experiments/e8_augment.py)
H13 Selection: aggregating the four single-precedent predictions with the model's own choice of the closest precedent (S-llmsel; texts only, no votes) raises AUROC(P against) over showing the four stratified precedents together (D-strat4-coal). One-sided, Holm across models. Secondary metric: macro-F1 after Batch Calibration.
H14 Bound: taking the single-precedent prediction of the stratified slot whose five-vote configuration equals the draft's (S-perfect; uses the label, so a bound and not a method) exceeds D-strat4-coal in AUROC(P against). The oracle gap is reported as selection + coverage.
H15a Outcome filter: in Choi's adopted-only pool, adding dissent-bearing documents raises Sup and bge R@10 for non-adopted drafts; adding unanimous documents changes neither.
H15b Topic: at equal K, topically similar dissent-bearing documents raise bge R@10 more than random ones.
H15c Dilution: in the unfiltered pool, adding K topically similar unanimous documents lowers bge R@10 on contested drafts, while stratified R@10 does not fall significantly.

## Follow-up analyses E7 and E8 (amendment; committed 2026-10-03 after their first outputs)
Specified on 2026-10-03 at about 12:30 KST in the analysis plan and in configs/cell49_select_augment.sh (text below, unchanged), before any E7 or E8 output existed. That bundle refused to run because E7 (Mistral) and E8 had already been executed outside it; logs/e7e8_provenance.log records whether the executed code is identical to the specified code. E7 and E8 are therefore reported as follow-up analyses with rules fixed before results, not as part of the original pre-registration. E8b (stratification depth under dilution) was specified after the E8 results and is exploratory.
H13 Selection: aggregating the four single-precedent predictions with the model's own choice of the closest precedent (S-llmsel; texts only, no votes) raises AUROC(P against) over showing the four stratified precedents together (D-strat4-coal). One-sided, Holm across models. Secondary metric: macro-F1 after Batch Calibration.
H14 Bound: taking the single-precedent prediction of the stratified slot whose five-vote configuration equals the draft's (S-perfect; uses the label, so a bound and not a method) exceeds D-strat4-coal in AUROC(P against). The oracle gap is reported as selection + coverage.
H15a Outcome filter: in Choi's adopted-only pool, adding dissent-bearing documents raises Sup and bge R@10 for non-adopted drafts; adding unanimous documents changes neither.
H15b Topic: at equal K, topically similar dissent-bearing documents raise bge R@10 more than random ones.
H15c Dilution: in the unfiltered pool, adding K topically similar unanimous documents lowers bge R@10 on contested drafts, while stratified R@10 does not fall significantly.
