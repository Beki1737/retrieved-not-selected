#!/usr/bin/env bash
# Cell 48 bundle (2026-10-03): non-LLM baselines (professor point 3), memorization definition fix, H12 test,
# baselines merged into the cross-model summary (D79). CPU only; does not touch the GPU runs. Safe to re-run.
set -e
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src
cd $PROJ
cat > $PROJ/src/coalrag/experiments/e6_baselines.py <<'E6BL'
"""E6 non-LLM baselines (professor point 3; D79) on the same 66 non-adopted drafts x 5 nations as the LLM runs, written in
the LLM row schema so every LLM metric applies. Only precedents strictly earlier than the draft, Config A pools (A + N).
  BL-majority            always favour
  BL-nation-all          the nation's vote distribution over all earlier Choi documents (adopted + non-adopted)
  BL-nation-nonadopted   the nation's vote distribution over earlier non-adopted drafts (in-distribution history)
  BL-copy-bge1           the nation's vote on the single most text-similar earlier precedent (bge-small)
  BL-knn10               rank-weighted (1/r) vote distribution of the nation over the 10 most similar precedents
  BL-strat4-vote         rank-weighted vote distribution over exactly the 4 stratified precedents shown in D-strat4-coal
Probabilities carry a fixed pseudo-count of 0.02 per option so that log-loss and AUROC are defined (no tuning)."""
import json, os
from pathlib import Path
import numpy as np
from coalrag.core.match import P5
from coalrag.retrieval.configA import ConfigA

STORE = Path(os.environ["PROJ"]) / "results" / "store"; OUT = STORE / "e4_baselines_main.jsonl"
L = ["Y", "N", "A"]; EPS = 0.02

def dist(votes, w=None):
    c = np.full(3, EPS)
    for i, v in enumerate(votes):
        if v in L: c[L.index(v)] += 1.0 if w is None else w[i]
    return c / c.sum()

cfg = ConfigA(); E = cfg.E["bge-small"]; rows = []
for q in sorted(cfg.N, key=lambda r: r["date"]):
    el = cfg.eligible(q, cfg.A) + cfg.eligible(q, cfg.N); elN = cfg.eligible(q, cfg.N); qv = E[cfg.pos[q["res_id"]]]
    top = [el[i] for i in np.argsort(-np.array([E[cfg.pos[c["res_id"]]] @ qv for c in el]), kind="stable")[:10]] if el else []
    strat = list(cfg.strat_slots(q, 4, True))
    for n in P5:
        t = cfg.vot[q["res_id"]][n]
        if t not in L: continue
        V = lambda docs: [cfg.vot[d["res_id"]][n] for d in docs]
        B = {"BL-majority": np.array([1 - 2 * EPS, EPS, EPS]), "BL-nation-all": dist(V(el)), "BL-nation-nonadopted": dist(V(elN)),
             "BL-copy-bge1": dist(V(top[:1])), "BL-knn10": dist(V(top), [1 / (r + 1) for r in range(len(top))]),
             "BL-strat4-vote": dist(V(strat), [1 / (r + 1) for r in range(len(strat))])}
        for c, p in B.items():
            rows.append(dict(qid=q["res_id"], symbol=q["symbol"], qset="vetoed" if q["vetoed"] else "failed", nation=n, cond=c, model="baseline",
                             pY=float(p[0]), pN=float(p[1]), pA=float(p[2]), pred=L[int(np.argmax(p))], true=t, retrieved=[], prompt_tokens=None, sec=0.0, error=None))
with open(OUT, "w") as f:
    for r in rows: f.write(json.dumps(r) + "\n")
print(f"wrote {len(rows)} rows ({len(rows) // 6} per baseline) to {OUT.name}")
E6BL
cat > $PROJ/src/coalrag/analysis/e5_analysis.py <<'E5AN'
"""Wave-2 analysis (D60 plan, fixed before results). Usage: python -m coalrag.analysis.e5_analysis <served> [--B 1000]
Reads e4_<served>_{main,wave2,allreg,think-off,think-on}.jsonl when present. Resolution-cluster paired bootstrap.
A evidence factorial and flip test | B order/k | C paraphrases | D memorization | E all regimes | F reasoning mode"""
import argparse, os
from pathlib import Path
import numpy as np, pandas as pd
from coalrag.analysis.e4_metrics import metrics

STORE = Path(os.environ["PROJ"]) / "results" / "store"; K = ["qid", "nation"]; LAB = ["Y", "N", "A"]


def load(m, tag):
    p = STORE / f"e4_{m}_{tag}.jsonl"
    if not p.exists(): return None
    d = pd.read_json(p, lines=True)
    d = d[d.error.isna() & d.true.isin(LAB)].drop_duplicates(K + ["cond"], keep="last").copy()
    P = d[["pY", "pN", "pA"]].values.astype(float)
    d["ptrue"] = P[np.arange(len(d)), d.true.map({"Y": 0, "N": 1, "A": 2}).values]
    d["pred"] = np.array(LAB)[P.argmax(1)]; d["hit"] = (d.pred == d.true).astype(float)
    return d


def stat(name):
    if name in ("ptrue", "hit"): return lambda g: float(g[name].mean())
    if name == "false_against": return lambda g: float(((g.pred == "N") & (g.true != "N")).sum() / max((g.true != "N").sum(), 1))
    return lambda g: metrics(g.true.values, g[["pY", "pN", "pA"]].values.astype(float))[name]


def align(frames):
    keys = set.intersection(*[set(zip(f.qid, f.nation)) for f in frames])
    return [f[[k in keys for k in zip(f.qid, f.nation)]].sort_values(K).reset_index(drop=True) for f in frames]


def paired(a, b, name, B, seed=0):
    a, b = align([a, b]); f = stat(name); q = a.qid.values; uq = np.unique(q)
    pos = {u: np.where(q == u)[0] for u in uq}; rng = np.random.default_rng(seed); bs = []
    for _ in range(B):
        ix = np.concatenate([pos[u] for u in rng.choice(uq, len(uq))]); bs.append(f(a.iloc[ix]) - f(b.iloc[ix]))
    d = f(a) - f(b); lo, hi = np.nanpercentile(bs, [2.5, 97.5]); star = "*" if lo > 0 or hi < 0 else " "
    return f"{d:+.3f} [{lo:+.3f},{hi:+.3f}]{star}"


def table(d, conds, cols=("hit", "ptrue", "macroF1_BC", "aucN", "yes_gap", "no_recall")):
    rows = []
    for c in conds:
        g = d[d.cond == c]
        if len(g): rows.append(dict(cond=c, n=len(g), **{k: round(stat(k)(g), 3) for k in cols}))
    return pd.DataFrame(rows).set_index("cond") if rows else pd.DataFrame()


def main(m, B):
    main_, w2, ar = load(m, "main"), load(m, "wave2"), load(m, "allreg")
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
    if w2 is not None and main_ is not None:
        # ---- A. evidence factorial on the oracle precedent ----
        F = ["F-orc-text", "F-orc-coal", "F-orc-others", "F-orc-flip", "F-rnd-coal", "F-rnd-orcv"]
        base = main_[main_.cond == "B0-std"]; fr = [base] + [w2[w2.cond == c] for c in F if c in set(w2.cond)]
        A = pd.concat(align(fr)); print(f"\n==== A. EVIDENCE FACTORIAL (one oracle precedent; keys={A.groupby('cond').size().min()}) ====")
        print(table(A, ["B0-std"] + F).to_string())
        g = {c: A[A.cond == c] for c in A.cond.unique()}
        C = [("votes | relevant text", "F-orc-coal", "F-orc-text"), ("relevant text | no votes", "F-orc-text", "B0-std"),
             ("correct vs own votes | random text", "F-rnd-orcv", "F-rnd-coal"), ("text relevance | correct votes", "F-orc-coal", "F-rnd-orcv"),
             ("own vote shown vs allies only", "F-orc-coal", "F-orc-others"), ("allies only vs text only", "F-orc-others", "F-orc-text"),
             ("flipped target vote", "F-orc-flip", "F-orc-coal")]
        print("\n-- paired contrasts (cluster bootstrap 95% CI; * = excludes 0) --")
        for lab, x, y in C:
            if x in g and y in g:
                print(f"{lab:38s} {x} - {y}: P(true) {paired(g[x], g[y], 'ptrue', B)} | acc {paired(g[x], g[y], 'hit', B)} | AUROC(N) {paired(g[x], g[y], 'aucN', B)}")
        if "F-orc-flip" in g and "F-orc-text" in g:
            fl, tx = align([g["F-orc-flip"], g["F-orc-text"]])
            col = {"Y": "pY", "N": "pN", "A": "pA"}
            fl["p_shown"] = [r[col[s]] for s, r in zip(fl.shown, fl.to_dict("records"))]
            tx["p_shown"] = [r[col[s]] for s, r in zip(fl.shown, tx.to_dict("records"))]
            fl["uptake"] = fl.p_shown - tx.p_shown; fl["follow"] = (fl.pred == fl.shown).astype(float)
            fl["case"] = fl.true + "->" + fl.shown
            print("\n-- flip test: uptake = P(shown label | flipped evidence) - P(same label | text only); follow = argmax equals shown --")
            print(fl.groupby("case").agg(n=("uptake", "size"), uptake=("uptake", "mean"), follow=("follow", "mean")).round(3).to_string())
            co, tx2 = align([g["F-orc-coal"], g["F-orc-text"]]); co["uptake_true"] = co.ptrue.values - tx2.ptrue.values
            print("-- correct evidence: uptake of the true label by true label --")
            print(co.groupby("true").uptake_true.agg(["size", "mean"]).round(3).to_string())
            a = fl[fl.case == "Y->N"].uptake; b = fl[fl.case == "N->Y"].uptake
            if len(a) and len(b):
                rng = np.random.default_rng(0); bs = [rng.choice(a.values, len(a)).mean() - rng.choice(b.values, len(b)).mean() for _ in range(B)]
                print(f"asymmetry: uptake(shown against | true favour) - uptake(shown favour | true against) = {a.mean() - b.mean():+.3f} "
                      f"[{np.percentile(bs, 2.5):+.3f},{np.percentile(bs, 97.5):+.3f}]")
        # ---- B. order and k ----
        R = ["D-strat4-coal", "R-strat4-rev", "R-strat4-shuf", "R-strat2-coal", "R-strat6-coal", "D-top4-coal"]
        fr = [main_[main_.cond == c] for c in ("B0-std", "D-strat4-coal", "D-top4-coal")] + [w2[w2.cond == c] for c in R[1:5]]
        Rd = pd.concat(align([f for f in fr if len(f)])); gg = {c: Rd[Rd.cond == c] for c in Rd.cond.unique()}
        print("\n==== B. ORDER AND k (stratified evidence, coalition view) ====")
        print(table(Rd, ["B0-std"] + R).to_string())
        for c in R[1:]:
            if c in gg: print(f"{c:15s} - D-strat4-coal: AUROC(N) {paired(gg[c], gg['D-strat4-coal'], 'aucN', B)} | P(true) {paired(gg[c], gg['D-strat4-coal'], 'ptrue', B)}")
        # ---- C. paraphrases ----
        P = sorted({c.split("-")[0] for c in w2.cond if c[0] == "P" and c[1].isdigit()})
        if P:
            rows = []
            for p, (b0, s4) in [("P0 (main)", ("B0-std", "D-strat4-coal"))] + [(p, (f"{p}-B0", f"{p}-strat4")) for p in P]:
                src = main_ if p.startswith("P0") else w2; x, y = src[src.cond == b0], src[src.cond == s4]
                if not len(x) or not len(y): continue
                tpl = "" if p.startswith("P0") else str(x.template.iloc[0])
                rows.append(dict(template=p, name=tpl, yes_rate_B0=(x.pred == "Y").mean(), aucN_B0=stat("aucN")(x), F1BC_B0=stat("macroF1_BC")(x),
                                 aucN_strat4=stat("aucN")(y), F1BC_strat4=stat("macroF1_BC")(y), d_aucN=paired(y, x, "aucN", B)))
            T = pd.DataFrame(rows).set_index("template")
            print("\n==== C. PARAPHRASE ROBUSTNESS (Choi templates) ====\n" + T.round(3).to_string())
            num = T[["yes_rate_B0", "aucN_B0", "aucN_strat4", "F1BC_B0", "F1BC_strat4"]]
            print("mean +- sd across templates:", {k: f"{v:.3f} +- {s:.3f}" for k, v, s in zip(num.columns, num.mean(), num.std())})
        # ---- D. memorization ----
        if "M-symbol" in set(w2.cond):
            M = w2[w2.cond == "M-symbol"]; print("\n==== D. MEMORIZATION PROBE (symbol + date only) ====")
            print(table(M, ["M-symbol"]).to_string(), "| majority-class acc:", round(M.true.value_counts(normalize=True).max(), 3))
            Mi = M.set_index(K); mem = (Mi.pred.eq(Mi.true) & Mi.true.ne("Y")).rename("memorized")  # D79: probe right on a non-favour vote
            print(f"memorized (probe correct on an against/abstention vote): {int(mem.sum())} of {(Mi.true != 'Y').sum()} non-favour rows")
            for c in ("D-strat4-coal", "D-oracle-coal", "D-bge-coal"):
                x, y = align([main_[main_.cond == c], base])
                j = x.set_index(K).ptrue.sub(y.set_index(K).ptrue).rename("gain").to_frame().join(mem, how="inner")
                print(f"{c:14s} gain in P(true) over B0-std: memorized {j[j.memorized].gain.mean():+.3f} (n={j.memorized.sum()}) | "
                      f"not memorized {j[~j.memorized].gain.mean():+.3f} (n={(~j.memorized).sum()})")
    # ---- E. all regimes ----
    if ar is not None and main_ is not None:
        E = pd.concat([ar, main_[main_.cond.isin(set(ar.cond))]]); print("\n==== E. ALL REGIMES (adopted queries from allreg + non-adopted from main) ====")
        rows = []
        for (c, s), g in E.groupby(["cond", "qset"]):
            notN = g.true != "N"
            rows.append(dict(cond=c, qset=s, n=len(g), yes_rate=(g.pred == "Y").mean(), true_yes=(g.true == "Y").mean(),
                             false_against=((g.pred == "N") & notN).sum() / max(notN.sum(), 1), no_recall=((g.pred == "N") & ~notN).sum() / max((~notN).sum(), 1),
                             F1BC=stat("macroF1_BC")(g)))
        print(pd.DataFrame(rows).set_index(["cond", "qset"]).round(3).to_string())
        print("-- pooled over all queries: AUROC(N) / macro-F1 (BC) --")
        for c in sorted(set(ar.cond)):
            g = E[E.cond == c]; print(f"{c:15s} n={len(g)} AUROC(N)={stat('aucN')(g):.3f} F1BC={stat('macroF1_BC')(g):.3f}")
        for c in sorted(set(ar.cond) - {"B0-std"}):
            x, y = E[E.cond == c], E[E.cond == "B0-std"]
            xc, yc = x[x.qset == "consensus"], y[y.qset == "consensus"]
            if len(xc) and len(yc): print(f"  H12 {c} - B0-std | consensus false-against rate {paired(xc, yc, 'false_against', B)}")
            for s in ["consensus", "split", "vetoed", "failed"]:
                xs, ys = x[x.qset == s], y[y.qset == s]
                if len(xs) and len(ys): print(f"  {c} - B0-std | {s:9s} P(true) {paired(xs, ys, 'ptrue', B)}")
    # ---- F. reasoning mode ----
    th = {t: load(m, t) for t in ("think-off", "think-on")}
    if all(v is not None for v in th.values()):
        print("\n==== F. REASONING MODE (thinking off vs on) ====")
        for t, d in th.items(): print(f"-- {t} --\n" + table(d, list(dict.fromkeys(d.cond))).to_string())
        on, off = th["think-on"], th["think-off"]
        for c in dict.fromkeys(on.cond):
            print(f"{c:15s} on - off: AUROC(N) {paired(on[on.cond == c], off[off.cond == c], 'aucN', B)} | P(true) {paired(on[on.cond == c], off[off.cond == c], 'ptrue', B)}")
        if "reason_tokens" in on: print("reasoning tokens: mean", round(on.reason_tokens.mean()), "| truncated share", round(on.truncated.mean(), 3))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("served"); ap.add_argument("--B", type=int, default=1000)
    a = ap.parse_args(); main(a.served, a.B)
E5AN
cat > $PROJ/src/coalrag/analysis/summary.py <<'SUMM'
"""Cross-model LLM summary (pre-registered H5-H7, D76). For every model with a complete main run:
  table 1: condition x model, macro-F1 after Batch Calibration (BC) / AUROC of P(against) / Yes-rate gap / No-recall
  table 2: pre-registered tests, one-sided resolution-cluster paired bootstrap (B draws), Holm within each model
Writes results/tables/llm_crossmodel.md and results/tables/llm_tests.csv.
Usage: python -m coalrag.analysis.summary [--B 2000] [--models m1,m2]"""
import argparse, os
from pathlib import Path
import numpy as np, pandas as pd
from coalrag.analysis.e4_metrics import metrics, add_cad

PROJ = Path(os.environ["PROJ"]); STORE = PROJ / "results" / "store"; OUT = PROJ / "results" / "tables"; K = ["qid", "nation"]
BL = ["BL-majority", "BL-nation-all", "BL-nation-nonadopted", "BL-copy-bge1", "BL-knn10", "BL-strat4-vote"]
CONDS = BL + ["B0-choi", "B0-std", "CF-LTorig", "CF-LT", "CF-bge", "CF-CSR3", "D-bge-text", "D-bge-target", "D-bge-coal",
         "D-random-coal", "D-oracle-coal", "D-top4-coal", "D-strat4-target", "D-strat4-coal",
         "D-random-coal+CAD1", "D-oracle-coal+CAD1", "D-strat4-coal+CAD1"]
TESTS = [  # (hypothesis, metric, condition a, condition b): one-sided H1: metric(a) > metric(b)
    ("H5", "aucN", "D-strat4-coal", "B0-std"), ("H5", "aucN", "D-oracle-coal", "B0-std"),
    ("H5", "macroF1_BC", "D-oracle-coal", "D-random-coal"),
    ("H6", "macroF1_BC", "D-strat4-coal", "B0-std"), ("H6", "macroF1_BC", "D-oracle-coal", "B0-std"),
    ("H7", "macroF1_BC", "D-strat4-coal+CAD1", "D-strat4-coal"), ("H7", "macroF1_BC", "D-oracle-coal+CAD1", "D-oracle-coal"),
    ("H7-control", "macroF1_BC", "D-random-coal+CAD1", "D-random-coal"),
    ("E-baseline", "macroF1_BC", "B0-std", "BL-nation-nonadopted"), ("E-baseline", "aucN", "B0-std", "BL-nation-nonadopted"),
    ("E-baseline", "macroF1_BC", "D-strat4-coal", "BL-strat4-vote"), ("E-baseline", "aucN", "D-strat4-coal", "BL-knn10"),
    ("E-baseline", "macroF1_BC", "D-oracle-coal", "BL-knn10")]


def load(m):
    p = STORE / f"e4_{m}_main.jsonl"
    d = pd.read_json(p, lines=True); d = d[d.error.isna() & d.true.isin(["Y", "N", "A"])].drop_duplicates(K + ["cond"], keep="last")
    d = add_cad(d, "B0-std")
    bl = STORE / "e4_baselines_main.jsonl"
    if bl.exists():  # D79: non-LLM baselines on the same (draft, nation) rows
        b = pd.read_json(bl, lines=True); d = pd.concat([d, b[b.true.isin(["Y", "N", "A"])]], ignore_index=True)
    keys = set.intersection(*[set(zip(g.qid, g.nation)) for _, g in d.groupby("cond")])
    return d[[k in keys for k in zip(d.qid, d.nation)]].sort_values(["cond"] + K).reset_index(drop=True), len(keys)


def holm(p):
    p = np.asarray(p, float); o = np.argsort(p); adj = np.empty_like(p); run = 0.0
    for r, i in enumerate(o):
        run = max(run, min(1.0, (len(p) - r) * p[i])); adj[i] = run
    return adj


def main(B, models):
    models = models or sorted(m for m in (p.name[3:-11] for p in STORE.glob("e4_*_main.jsonl")) if m != "baselines")
    OUT.mkdir(parents=True, exist_ok=True); T1, T2 = [], []
    for m in models:
        d, nk = load(m); g = {c: x for c, x in d.groupby("cond")}
        qids = np.array(sorted(d.qid.unique())); rng = np.random.default_rng(0)
        pos = {c: {q: np.where(g[c].qid.values == q)[0] for q in qids} for c in g}
        pt = {c: metrics(g[c].true.values, g[c][["pY", "pN", "pA"]].values.astype(float)) for c in g}
        for c in CONDS:
            if c in pt: T1.append(dict(model=m, cond=c, **{k: pt[c][k] for k in ("macroF1", "macroF1_BC", "aucN", "yes_gap", "no_recall", "acc")}))
        need = sorted({c for _, _, a, b in TESTS for c in (a, b) if c in g}); boot = {c: [] for c in need}
        for _ in range(B):
            s = rng.choice(qids, len(qids))
            for c in need:
                ix = np.concatenate([pos[c][q] for q in s])
                boot[c].append(metrics(g[c].true.values[ix], g[c][["pY", "pN", "pA"]].values[ix].astype(float)))
        rows = []
        for h, k, a, b in TESTS:
            if a not in g or b not in g: continue
            db = np.array([x[k] - y[k] for x, y in zip(boot[a], boot[b])], float); db = db[~np.isnan(db)]
            rows.append(dict(model=m, hyp=h, metric=k, a=a, b=b, delta=pt[a][k] - pt[b][k], lo=np.percentile(db, 2.5), hi=np.percentile(db, 97.5),
                             p_one_sided=(1 + np.sum(db <= 0)) / (len(db) + 1)))
        fam = [i for i, r in enumerate(rows) if r["hyp"].startswith("H") and r["hyp"] != "H7-control"]
        adj = holm([rows[i]["p_one_sided"] for i in fam])
        for i, r in enumerate(rows): r["p_holm"] = adj[fam.index(i)] if i in fam else np.nan
        T2 += rows
        bc_up = sum(pt[c]["macroF1_BC"] >= pt[c]["macroF1"] for c in g if "+" not in c and not c.startswith("BL-"))
        print(f"{m}: {nk} (draft, nation) pairs in every condition | H6 part 1: BC >= raw macro-F1 in {bc_up}/{sum('+' not in c and not c.startswith('BL-') for c in g)} conditions")
    t1, t2 = pd.DataFrame(T1), pd.DataFrame(T2)
    cell = lambda r: f"{r.macroF1_BC:.3f} / {r.aucN:.3f} / {r.yes_gap:+.2f} / {r.no_recall:.2f}"
    tab = t1.assign(v=t1.apply(cell, axis=1)).pivot(index="cond", columns="model", values="v").reindex([c for c in CONDS if c in set(t1.cond)])
    t2.to_csv(OUT / "llm_tests.csv", index=False); t1.to_csv(OUT / "llm_conditions.csv", index=False)
    fmt = t2.assign(delta=t2.delta.map("{:+.3f}".format), ci=t2.apply(lambda r: f"[{r.lo:+.3f}, {r.hi:+.3f}]", axis=1),
                    p=t2.p_one_sided.map("{:.4f}".format), p_holm=t2.p_holm.map(lambda x: "" if pd.isna(x) else f"{x:.4f}"))[
        ["model", "hyp", "metric", "a", "b", "delta", "ci", "p", "p_holm"]]
    def mdtab(x, index=True):
        try: return x.to_markdown(index=index)
        except ImportError: return "```\n" + x.to_string(index=index) + "\n```"
    md = ["# LLM results across models", "", "Cell = macro-F1 after Batch Calibration / AUROC of P(against) / Yes-rate gap / No-recall", "",
          mdtab(tab), "", "## Pre-registered tests (one-sided, resolution-cluster bootstrap; Holm within model over H5-H7; H7-control and E-baseline rows are exploratory)", "",
          mdtab(fmt, False)]
    (OUT / "llm_crossmodel.md").write_text("\n".join(md))
    with pd.option_context("display.width", 260, "display.max_columns", 20, "display.max_colwidth", 40):
        print("\n==== Table 1: macro-F1(BC) / AUROC(N) / Yes-gap / No-recall ====\n" + tab.to_string())
        print("\n==== Table 2: pre-registered tests ====\n" + fmt.to_string(index=False))
    print(f"\nwritten: {OUT / 'llm_crossmodel.md'}, llm_tests.csv, llm_conditions.csv")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--B", type=int, default=2000); ap.add_argument("--models", default="")
    a = ap.parse_args(); main(a.B, [x for x in a.models.split(",") if x])
SUMM
grep -q "^- D79" $PROJ/configs/DECISIONS.md || cat >> $PROJ/configs/DECISIONS.md <<'DEC'
- D79 Non-LLM baselines on the same 330 (draft, nation) rows, leakage-safe (earlier precedents only): always-favour, the nation's historical vote distribution (all earlier Choi documents; earlier non-adopted drafts only), copy the most similar precedent's vote, rank-weighted 10-NN vote, and the rank-weighted vote of the 4 stratified precedents shown to the LLM. Reported in Table 1 of every model; LLM-vs-baseline contrasts are exploratory (outside the Holm family). Memorization is redefined as "the symbol-only probe is right on an against or abstention vote", because the earlier P(true) > 0.5 rule counted an affirmative model's default favour answers as memorized.
DEC
python -m py_compile src/coalrag/experiments/e6_baselines.py src/coalrag/analysis/e5_analysis.py src/coalrag/analysis/summary.py
git add -A && git -c user.name=becky1 -c user.email=becky1@andlab commit -qm "D79: non-LLM baselines, memorization fix, H12 test" && git log -1 --format="commit %h" || echo "nothing new to commit"
A=$PROJ/logs/analysis
python -W ignore -m coalrag.experiments.e6_baselines
python -W ignore -m coalrag.analysis.summary --B 2000 > $A/summary.log 2>&1
for m in mistral-small-24b-2501-fp8 qwen2.5-7b; do python -W ignore -m coalrag.analysis.e5_analysis $m --B 1000 > $A/e5_$m.log 2>&1; done
cat $A/summary.log
echo "########## memorization (D79 definition)"; grep -h -A4 "MEMORIZATION" $A/e5_mistral-small-24b-2501-fp8.log $A/e5_qwen2.5-7b.log | grep -E "memorized|gain"
