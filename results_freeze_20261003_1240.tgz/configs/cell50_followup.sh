#!/usr/bin/env bash
# Cell 50 bundle (2026-10-03 afternoon): provenance check of the E7/E8 code that ran outside cell49, honest amendment
# (follow-up analyses, not pre-registered), decisions D80-D84, E8b depth follow-up, E7 on Qwen-32B via the GPU 7 server.
set -u
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src
cd $PROJ
echo "== 1. provenance: executed code vs the code specified in cell49_select_augment.sh =="
python - <<'CHK' | tee $PROJ/logs/e7e8_provenance.log
import os, re, hashlib, pathlib
P = pathlib.Path(os.environ["PROJ"]); b = (P / "configs/cell49_select_augment.sh").read_text()
ok = True
for path, tag in [("src/coalrag/experiments/e7_select.py", "E7S"), ("src/coalrag/analysis/e7_analysis.py", "E7A"), ("src/coalrag/experiments/e8_augment.py", "E8A")]:
    m = re.search(r"cat > \$PROJ/" + re.escape(path) + r" <<'" + tag + r"'\n(.*?)\n" + tag + r"\n", b, re.S)
    spec = (m.group(1) + "\n") if m else None; f = P / path; run = f.read_text() if f.exists() else None
    same = spec is not None and run is not None and spec.strip() == run.strip(); ok &= same
    h = lambda s: hashlib.md5(s.strip().encode()).hexdigest()[:10] if s else "missing"
    print(f"{path}: specified {h(spec)} | executed {h(run)} | {'IDENTICAL' if same else 'DIFFERENT'}")
print("ALL IDENTICAL" if ok else "DIFFERENCES FOUND: E7/E8 results must be re-run from the specified code")
CHK
git log --format="%h %ad %s" -- src/coalrag/experiments/e7_select.py src/coalrag/experiments/e8_augment.py | head -3
echo "== 2. server used for the Mistral E7 run (engine, generation config) =="
for f in $(ls -t $PROJ/logs/vllm_*.log 2>/dev/null | head -4); do echo "  $(basename $f): $(grep -ohE "Initializing a V[01] LLM engine|V1 LLM engine|generation.config[^,]*" $f | sort -u | tr '\n' ' ' | cut -c1-160)"; done
cat > $PROJ/src/coalrag/experiments/e8b_depth.py <<'E8B'
"""E8b (exploratory follow-up, D84): E8 found that similar unanimous documents cut stratified-50 R@10 more than bge R@10
(H15c not supported). Hypothesis from D64: stratified recall beyond rank 10 lives at ranks 11-50, exactly where similar
dilution lands, so stratifying deeper should restore robustness. Same pools, candidates, arms and seeds as E8; adds
stratification depth 200 and the whole pool, and the paired similar-vs-random test at K=100 that H15b needs."""
import os, zlib
os.environ.setdefault("CKG_VERSION", "v1_2")
import numpy as np, pandas as pd
from coalrag.data.configB import load, match_vec
from coalrag.retrieval.configA import ConfigA

Kdf, T, TOK, V, H, EMB = load(partial_veto_coding=True, with_emb=True)
E = EMB["bge-small"]; rid = Kdf.res_id.tolist(); pos = {r: i for i, r in enumerate(rid)}
dates = Kdf.date.values; REG = Kdf.regime.values
cfg = ConfigA(); A = [pos[r["res_id"]] for r in cfg.A if r["res_id"] in pos]; N = [pos[r["res_id"]] for r in cfg.N if r["res_id"] in pos]
choi = set(A) | set(N); complete = lambda i: bool(((V[i] >= 1) & (V[i] <= 3)).all())
cand = np.array([i for i in range(len(rid)) if i not in choi and dates[i] < np.datetime64("2013-01-01") and complete(i)])
MODE = {"unanimous": cand[(V[cand] == 1).all(1)], "dissent": cand[~(V[cand] == 1).all(1)]}
SEEDS = [0, 1, 2]


def strat(order, Vp, depth, k=10):
    seen, out = set(), []
    for j in (order if depth is None else order[:depth]):
        key = tuple(Vp[j])
        if key not in seen:
            seen.add(key); out.append(j)
        if len(out) == k: break
    return np.array(out, dtype=int)


def measure(q, pool):
    pool = np.asarray(pool, dtype=int); h, _ = match_vec(V[pool], V[q], 0, "answer"); o = np.argsort(-(E[pool] @ E[q]), kind="stable")
    r = dict(sup=bool(h.any()), bge=bool(h[o[:10]].any()))
    for d in (50, 200, None): r[f"strat{d or 'all'}"] = bool(h[strat(o, V[pool], d)].any())
    return r


def added(q, mode, k, how, sd=0):
    C = MODE[mode]; k = min(k, len(C))
    if how == "similar": return C[np.argsort(-(E[C] @ E[q]), kind="stable")[:k]].tolist()
    return np.random.default_rng(zlib.crc32(f"{rid[q]}|{mode}|{k}|{sd}".encode())).choice(C, k, replace=False).tolist()


rows = []
for base, queries, src in [("F", N, A), ("U", sorted(choi), sorted(choi))]:
    for q in queries:
        if not complete(q) or (base == "U" and REG[q] not in ("split", "vetoed", "failed")): continue
        bp = [j for j in src if dates[j] < dates[q]]
        if len(bp) < 10: continue
        arms = [("none", [[]])]
        arms += [(f"{m}-similar-{k}", [added(q, m, k, "similar")]) for m in MODE for k in (100, 400)]
        arms += [(f"{m}-random-{k}", [added(q, m, k, "random", s) for s in SEEDS]) for m in MODE for k in (100, 400)]
        for arm, adds in arms:
            ms = pd.DataFrame([measure(q, bp + a) for a in adds]).mean()
            rows.append(dict(base=base, qid=rid[q], regime=REG[q], arm=arm, **ms.to_dict()))
df = pd.DataFrame(rows); rng = np.random.default_rng(0)


def pd_(sub, a, b, col, B=5000):
    x = sub[sub.arm == a].set_index("qid")[col]; y = sub[sub.arm == b].set_index("qid")[col]; d = (x - y).dropna().values
    bs = d[rng.integers(0, len(d), (B, len(d)))].mean(1)
    return f"{100 * d.mean():+5.1f} [{100 * np.percentile(bs, 2.5):+5.1f},{100 * np.percentile(bs, 97.5):+5.1f}]"


U = df[df.base == "U"]; F = df[df.base == "F"]
print(f"==== E8b, unfiltered pool, contested drafts (n={U[U.arm == 'none'].qid.nunique()}): R@10 % by stratification depth ====")
cols = ["bge", "strat50", "strat200", "stratall"]
print((100 * U.groupby("arm")[cols].mean()).round(1).loc[["none", "unanimous-similar-100", "unanimous-similar-400", "unanimous-random-100", "unanimous-random-400"]].to_string())
print("-- change vs no augmentation (pp, 95% CI) --")
for arm in ["unanimous-similar-100", "unanimous-similar-400"]:
    print(f"{arm:22s} " + " | ".join(f"{c} {pd_(U, arm, 'none', c)}" for c in cols))
print(f"\n==== H15b, outcome-filtered pool (n={F[F.arm == 'none'].qid.nunique()}): dissent similar minus random at K=100 (pp, 95% CI) ====")
print(" | ".join(f"{c} {pd_(F, 'dissent-similar-100', 'dissent-random-100', c)}" for c in ["sup", "bge", "strat50", "stratall"]))
if len(MODE["dissent"]) < 400: print(f"note: only {len(MODE['dissent'])} dissent-bearing candidates exist, so K=400 adds all of them in both topic arms (not a valid quantity level)")
E8B
grep -q '^## Follow-up analyses E7 and E8' $PROJ/configs/prereg.md || cat >> $PROJ/configs/prereg.md <<'PREREG'

## Follow-up analyses E7 and E8 (amendment; committed 2026-10-03 after their first outputs)
Specified on 2026-10-03 at about 12:30 KST in the analysis plan and in configs/cell49_select_augment.sh (text below, unchanged), before any E7 or E8 output existed. That bundle refused to run because E7 (Mistral) and E8 had already been executed outside it; logs/e7e8_provenance.log records whether the executed code is identical to the specified code. E7 and E8 are therefore reported as follow-up analyses with rules fixed before results, not as part of the original pre-registration. E8b (stratification depth under dilution) was specified after the E8 results and is exploratory.
H13 Selection: aggregating the four single-precedent predictions with the model's own choice of the closest precedent (S-llmsel; texts only, no votes) raises AUROC(P against) over showing the four stratified precedents together (D-strat4-coal). One-sided, Holm across models. Secondary metric: macro-F1 after Batch Calibration.
H14 Bound: taking the single-precedent prediction of the stratified slot whose five-vote configuration equals the draft's (S-perfect; uses the label, so a bound and not a method) exceeds D-strat4-coal in AUROC(P against). The oracle gap is reported as selection + coverage.
H15a Outcome filter: in Choi's adopted-only pool, adding dissent-bearing documents raises Sup and bge R@10 for non-adopted drafts; adding unanimous documents changes neither.
H15b Topic: at equal K, topically similar dissent-bearing documents raise bge R@10 more than random ones.
H15c Dilution: in the unfiltered pool, adding K topically similar unanimous documents lowers bge R@10 on contested drafts, while stratified R@10 does not fall significantly.
PREREG
grep -q "^- D80" $PROJ/configs/DECISIONS.md || cat >> $PROJ/configs/DECISIONS.md <<'DEC'
- D80 Positioning (independence from Choi et al.): the paper is built on our dataset (UNSC-CKG v1.2 supplies every vote), our evaluation protocol (option-likelihood scoring, controlled evidence views, exact-configuration retrieval metrics, calibrated LLM metrics, non-LLM baselines) and our findings. Choi et al.'s released documents are used as the text source for 581 drafts and cited as data. Their pipeline appears as one reimplemented prior-pipeline row (CF-LTorig) in the main table; the other CF variants and the replication notes go to an appendix, described neutrally. No sentence frames the paper as a correction of that work. Cited in the third person (double-blind).
- D81 E7 selection experiment: each stratified precedent scored alone, plus the model's own choice of the closest precedent (texts only); aggregation rules fixed in e7_analysis.py; nothing tuned.
- D82 Professor point 2 is answered by E8 (CKG documents outside Choi's set; K in {100, 400}; topic similar vs random; mode unanimous vs dissent-bearing; outcome-filtered and unfiltered pools). Point 5 (second behavioural domain) is deferred to the follow-up paper and stated as a limitation: the Art. 27(3) outcome filter has no General Assembly counterpart, so a GA replication would test only the crowding half of the claim, and it needs a separate vote-data pipeline that cannot be validated before the freeze.
- D83 Provenance: E7 (Mistral, GPU 8) and E8 ran before the H13-H15 text was committed. They are reported as follow-up analyses with rules fixed before results; the paper never calls them pre-registered. The code check is in logs/e7e8_provenance.log.
- D84 E7/E8 results. E8: H15a supported (adopted-only pool: dissent-bearing additions raise Sup 1.5 -> 47-55% and bge R@10 0 -> 19.7%; unanimous additions change nothing). Only 295 dissent-bearing candidates exist, so K = 400 equals "all of them" in both topic arms and is not a valid quantity level. H15b at K = 100: similar 45.5 / 19.7 vs random 31.3 / 13.1 (Sup / bge R@10); paired test in E8b. H15c NOT supported: similar unanimous dilution lowers stratified-50 R@10 by 16.1 pp [10.5, 22.4] vs bge 4.2 pp; random dilution is 4x milder, so topical similarity drives crowding. E8b tests whether deeper stratification restores robustness (exploratory). E7 (Mistral): H13 not supported (S-llmsel minus D-strat4-coal AUROC -0.011); H14 supported (S-perfect +0.138 [0.064, 0.217]); oracle gap 0.171 = selection 0.138 + coverage/presentation 0.033; a matching slot exists for 45.5% of drafts and the model's selector picks it 33.3% of the time, the same as taking the most similar precedent (chance 25%).
DEC
git add -A && git -c user.name=becky1 -c user.email=becky1@andlab commit -qm "E7/E8 provenance amendment (follow-up, not pre-registered); D80-D84; E8b" && git log -1 --format="commit %h %ad" || echo "nothing new to commit"
echo "== 3. E8b depth follow-up (exploratory) =="
python -W ignore -m coalrag.experiments.e8b_depth 2>&1 | tee $PROJ/logs/e8b_depth.log
echo "== 4. E7 on Qwen-32B through the GPU 7 server (only if the code check passed) =="
S7=$(curl -s -m 10 127.0.0.1:8007/v1/models | python -c "import sys,json; print(json.load(sys.stdin)['data'][0]['id'])" 2>/dev/null)
if grep -q "ALL IDENTICAL" $PROJ/logs/e7e8_provenance.log && [ "$S7" = "qwen2.5-32b-gptq-int8" ]; then
  nohup python -W ignore -m coalrag.experiments.e7_select --served qwen2.5-32b-gptq-int8 --base http://127.0.0.1:8007/v1 --conc 8 > $PROJ/logs/e7_qwen2.5-32b-gptq-int8.log 2>&1 &
  echo "  E7 32B started (pid $!) on :8007"
else echo "  E7 32B NOT started (code check or server check failed: port 8007 serves '$S7')"; fi
tail -3 $PROJ/logs/gpuq3.log
