#!/usr/bin/env bash
# Cell 39b bundle (2026-10-02): wave-2 runner, wave-2 analysis, E1f (depth / embargo / router), GPU queue,
# e4_metrics --truth patch, pre-registration addendum H8-H12, decisions D56-D61, git commit. CPU only; safe to re-run.
set -e
source $HOME/miniforge3/etc/profile.d/conda.sh && conda activate crag
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src
cd $PROJ
cat > $PROJ/src/coalrag/experiments/e5_wave2.py <<'E5W2'
"""Wave 2 (D60). Reuses the pre-registered e4 runner unchanged: main conditions are delegated to e4_llm.Runner.run_one,
new conditions build prompts here and are scored with the same option-likelihood method.
  F  evidence-intervention factorial on the oracle precedent (one precedent, identical text across arms)
  R  order and k robustness of stratified evidence
  P  Choi et al. paraphrase templates (auto-discovered in VoteTemplates.py), zero-shot and with stratified evidence
  M  memorization probe (draft symbol and date only)
  AR all-regime run (use --queries adopted)
  --think off|on  Qwen3 reasoning mode: off = empty think block; on = sampled reasoning (budget-forced), then scoring
Output: results/store/e4_{served}_{tag}.jsonl, same schema as e4 plus optional fields (shown, template, think, ...)."""
import argparse, ast, asyncio, json, math, os, random, re, string, time
from pathlib import Path
from coalrag.core.match import P5
from coalrag.retrieval.configA import ConfigA, NAME
from coalrag.llm.client import LLM, verify_served, OPTS, LBL
from coalrag.llm import prompts as PR
from coalrag.experiments import e4_llm as E4

PROJ = Path(os.environ["PROJ"]); STORE = PROJ / "results" / "store"; LOGS = PROJ / "logs"; HOME = Path.home()
for k, v in {"qwen2.5-32b-gptq-int8": HOME / "models/Qwen2.5-32B-Instruct-GPTQ-Int8",
             "mistral-small-24b-2501-fp8": HOME / "models/Mistral-Small-24B-Instruct-2501-FP8-dynamic",
             "qwen3-8b": HOME / "models/Qwen3-8B"}.items():
    E4.MODELS.setdefault(k, str(v))
WORD, ctx = E4.WORD, E4.ctx
FLIP = {"Y": "N", "N": "Y", "A": "N"}
MEM = ("You are a representative of {country} in the United Nations Security Council (UNSC).\n"
       "On {date}, the Security Council voted on draft resolution {symbol}.\n"
       "How did {country} vote on this draft? The vote must be one of three options: favour, against, or abstention.\n\n{fmt}")
GROUPS = {
    "F": ["F-orc-text", "F-orc-coal", "F-orc-flip", "F-orc-others", "F-rnd-coal", "F-rnd-orcv"],
    "R": ["R-strat4-rev", "R-strat4-shuf", "R-strat2-coal", "R-strat6-coal"],
    "M": ["M-symbol"],
    "AR": ["B0-std", "D-bge-coal", "D-strat4-coal"],
    "THINK": ["B0-std", "D-bge-coal", "D-random-coal", "D-oracle-coal", "D-strat4-coal", "F-orc-coal", "F-orc-flip"]}
SENT = "@@DRAFT@@"


def choi_paraphrases(limit=4):
    """String templates in Choi's VoteTemplates.py that (i) take a country and a draft, (ii) are single-turn vote prompts
    (no history or reflexion), (iii) differ from the templates already used in the main run."""
    src = next((PROJ / "data/raw/Nation-Level_Bias").rglob("VoteTemplates.py"), None)
    if src is None: return {}
    found = []
    for node in ast.walk(ast.parse(src.read_text(encoding="utf-8"))):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)): continue
        tg = node.targets[0] if isinstance(node, ast.Assign) else node.target
        name = tg.id if isinstance(tg, ast.Name) else getattr(tg, "attr", "anon")
        val = node.value
        if isinstance(val, ast.Constant): items = [(name, val)]
        elif isinstance(val, (ast.List, ast.Tuple)): items = [(f"{name}[{i}]", v) for i, v in enumerate(val.elts)]
        elif isinstance(val, ast.Dict): items = [(f"{name}[{getattr(k, 'value', i)}]", v) for i, (k, v) in enumerate(zip(val.keys, val.values))]
        else: items = []
        found += [(n, v.value) for n, v in items if isinstance(v, ast.Constant) and isinstance(v.value, str)]
    norm = lambda t: re.sub(r"\s+", " ", t).strip()
    seen = {norm(t) for t in (PR.BASIC, PR.WITH_HISTORY, PR.WITHOUT_HISTORY, PR.REFLEXION)}; out = {}
    for name, t in found:
        low = t.lower()
        if "against" not in low or any(w in low for w in ("predecessor", "previous", "reflect", "histor")): continue
        try: fields = {f for _, f, _, _ in string.Formatter().parse(t) if f}
        except ValueError: continue
        role = {}
        for f in fields:
            fl = f.lower()
            if "country" in fl or "nation" in fl: role[f] = "country"
            elif "format" in fl: role[f] = "fmt"
            elif any(w in fl for w in ("resolution", "query", "draft", "context")): role[f] = "draft"
            else: role = None; break
        if not role or "draft" not in role.values() or "country" not in role.values() or norm(t) in seen: continue
        try: t.format(**{f: "x" for f in role})
        except Exception: continue
        seen.add(norm(t)); out[name] = (t, role)
        if len(out) == limit: break
    return out


def para_prompt(tpl, role, country, q, blk=""):
    u = tpl.format(**{f: (country if r == "country" else PR.ANSWER_ONE_WORD if r == "fmt" else SENT) for f, r in role.items()})
    if "fmt" not in role.values(): u = u.rstrip() + "\n\n" + PR.ANSWER_ONE_WORD
    if blk:  # evidence goes before the draft header line, as in the main D-conditions
        L = u.split("\n"); i = next(j for j, l in enumerate(L) if SENT in l)
        if L[i].strip() == SENT and i > 0 and "draft" in L[i - 1].lower() and len(L[i - 1]) < 80: i -= 1
        L.insert(i, blk.rstrip("\n")); u = "\n".join(L)
    return u.replace(SENT, ctx(q))


def block(cfg, slots, n, view, over=None):
    """Identical layout to prompts.precedent_block, plus view 'others' and displayed-vote overrides (res_id -> votes)."""
    if not slots: return ""
    L = ["Consider the following similar past draft resolutions in <similar_past_resolutions>.", "<similar_past_resolutions>"]
    for i, d in enumerate(slots, 1):
        L.append(f"[{i}] Date: {d['date'].date()} | Outcome: {'adopted' if d['adopted'] else 'not adopted'}")
        L.append(f"Summary: {d.get('summary') or ''}")
        v = (over or {}).get(d["res_id"], cfg.vot[d["res_id"]])
        if view == "target": L.append(f"Vote of {NAME[n]}: {WORD[v[n]]}")
        if view == "coalition": L.append("Votes of the permanent members: " + "; ".join(f"{NAME[m]}: {WORD[v[m]]}" for m in P5))
        if view == "others": L.append("Votes of the other permanent members: " + "; ".join(f"{NAME[m]}: {WORD[v[m]]}" for m in P5 if m != n))
    L.append("</similar_past_resolutions>")
    return "\n".join(L) + "\n"


def d_prompt(country, q, blk):
    """Exactly the e4 D-condition construction: WITHOUT_HISTORY with the evidence block before the draft header."""
    u = PR.WITHOUT_HISTORY.format(country=country, answer_format=PR.ANSWER_ONE_WORD, query=ctx(q))
    return u.replace("<draft_resolution> :", blk + "\n<draft_resolution> :", 1)


async def score_prefix(llm, prefix):
    pre = llm.tok(prefix, add_special_tokens=False).input_ids
    lps = await asyncio.gather(*[llm._lp(prefix, pre, o) for o in OPTS])
    z = max(lps); w = [math.exp(v - z) for v in lps]; s = sum(w)
    return {LBL[o]: w[i] / s for i, o in enumerate(OPTS)}, len(pre)


async def think_prefix(llm, user, mode, budget):
    base = llm.tok.apply_chat_template([{"role": "user", "content": user}], tokenize=False, add_generation_prompt=True,
                                       enable_thinking=(mode == "on"))
    if mode == "off": return base, {}
    async with llm.sem:
        r = await llm.cli.completions.create(model=llm.m, prompt=base, max_tokens=budget, temperature=0.6, top_p=0.95, seed=0,
                                             stop=["</think>"], extra_body={"add_special_tokens": False, "top_k": 20})
    c = r.choices[0]; txt = c.text or ""
    if "<think>" not in txt[:20]: txt = "<think>\n" + txt.lstrip()
    return base + txt.rstrip() + "\n</think>\n\n", {"reason_tokens": r.usage.completion_tokens, "truncated": c.finish_reason == "length"}


class W2(E4.Runner):
    def __init__(self, llm, cfg, out, think="none", budget=1024, paras=None):
        super().__init__(llm, cfg, out)
        for k, v in dict(cache={}, samples={}, lock=asyncio.Lock(), n=0, t0=time.time()).items():
            if not hasattr(self, k): setattr(self, k, v)
        self.out, self.think, self.budget, self.paras = out, think, budget, list((paras or {}).items())

    @staticmethod
    def qset(q): return q.get("regime") if q["adopted"] else ("vetoed" if q["vetoed"] else "failed")

    def fslots(self, q, n, cond):
        cfg = self.cfg; o = cfg.oracle(q)
        if o is None: return None
        doc = o
        if cond.startswith("F-rnd"):
            pool = [c for c in cfg.eligible(q, cfg.A if o["adopted"] else cfg.N) if c["res_id"] != o["res_id"]]
            if not pool: return None
            doc = random.Random(f"{q['res_id']}|rnd").choice(pool)
        view, over = {"text": "text", "others": "others"}.get(cond.split("-")[-1], "coalition"), None
        if cond == "F-orc-flip":
            v = dict(cfg.vot[o["res_id"]]); v[n] = FLIP[v[n]]; over = {o["res_id"]: v}
        if cond == "F-rnd-orcv": over = {doc["res_id"]: dict(cfg.vot[o["res_id"]])}
        shown = (over or {}).get(doc["res_id"], cfg.vot[doc["res_id"]])[n] if view == "coalition" else None
        return doc, view, over, shown

    def rslots(self, q, cond):
        c = self.cfg
        if cond == "R-strat4-rev": return list(c.strat_slots(q, 4, True))[::-1]
        if cond == "R-strat4-shuf":
            s = list(c.strat_slots(q, 4, True)); random.Random(f"{q['res_id']}|shuf").shuffle(s); return s
        return c.strat_slots(q, int(cond[len("R-strat")]), True)

    async def build(self, q, n, cond):
        cfg, country = self.cfg, NAME[n]
        if cond == "B0-std": return PR.WITHOUT_HISTORY.format(country=country, answer_format=PR.ANSWER_ONE_WORD, query=ctx(q)), [], {}
        if cond.startswith("D-"):
            sl = self.slots(q, cond); view = {"text": "text", "target": "target", "coal": "coalition"}[cond.split("-")[-1]]
            return d_prompt(country, q, PR.precedent_block(sl, view, n, cfg.vot, NAME, WORD, P5)), [d["res_id"] for d in sl], {}
        if cond.startswith("F-"):
            r = self.fslots(q, n, cond)
            if r is None: return None
            doc, view, over, shown = r
            return d_prompt(country, q, block(cfg, [doc], n, view, over)), [doc["res_id"]], {"shown": shown}
        if cond.startswith("R-"):
            sl = self.rslots(q, cond)
            return d_prompt(country, q, block(cfg, sl, n, "coalition")), [d["res_id"] for d in sl], {}
        if cond.startswith("M-"):
            return MEM.format(country=country, date=q["date"].date().isoformat(), symbol=q["symbol"], fmt=PR.ANSWER_ONE_WORD), [], {}
        m = re.fullmatch(r"P(\d+)-(B0|strat4)", cond)
        if m:
            name, (tpl, role) = self.paras[int(m.group(1)) - 1]
            sl = cfg.strat_slots(q, 4, True) if m.group(2) == "strat4" else []
            return para_prompt(tpl, role, country, q, block(cfg, sl, n, "coalition")), [d["res_id"] for d in sl], {"template": name}
        raise ValueError(f"unknown condition {cond}")

    async def run_one(self, q, n, cond):
        if cond in E4.CONDS and not q["adopted"] and self.think == "none":
            return await super().run_one(q, n, cond)
        t = time.time(); err = p = ntok = None; ret = []; extra = {}
        try:
            b = await self.build(q, n, cond)
            if b is None: return
            user, ret, extra = b
            self.samples.setdefault(cond, f"[{q['symbol']} | {NAME[n]}]\n{user}")
            if self.think == "none": p, ntok = await self.llm.score(user)
            else:
                pre, info = await think_prefix(self.llm, user, self.think, self.budget); extra.update(info)
                p, ntok = await score_prefix(self.llm, pre)
        except Exception as e:
            err = f"{type(e).__name__}: {str(e)[:200]}"
        rec = dict(qid=q["res_id"], symbol=q["symbol"], qset=self.qset(q), nation=n, cond=cond, model=self.llm.m,
                   pY=p["Y"] if p else None, pN=p["N"] if p else None, pA=p["A"] if p else None,
                   pred=max(p, key=p.get) if p else None, true=self.cfg.vot[q["res_id"]][n], retrieved=ret,
                   prompt_tokens=ntok, sec=round(time.time() - t, 2), error=err, think=self.think, **extra)
        async with self.lock:
            with open(self.out, "a") as f: f.write(json.dumps(rec) + "\n")
            self.n += 1
            if self.n % 200 == 0: print(f"  {self.n} done | {time.time() - self.t0:.0f}s", flush=True)


def expand(spec, paras):
    G = dict(GROUPS, main=list(E4.CONDS), P=[f"P{i}-{k}" for i in range(1, len(paras) + 1) for k in ("B0", "strat4")])
    G["wave2"] = G["F"] + G["R"] + G["P"] + G["M"]
    out = []
    for tok in spec.split(","):
        out += G.get(tok, [tok])
    return list(dict.fromkeys(out))


def selftest(cfg):
    """The local block builder must reproduce prompts.precedent_block exactly for the shared views."""
    for q in cfg.N[:5]:
        sl = cfg.strat_slots(q, 4, True)
        for view in ("text", "target", "coalition"):
            for n in P5:
                assert block(cfg, sl, n, view) == PR.precedent_block(sl, view, n, cfg.vot, NAME, WORD, P5), (q["res_id"], view, n)
    print("[selftest] evidence block identical to e4 for text/target/coalition views")


async def amain(a):
    cfg = ConfigA(); selftest(cfg)
    llm = LLM(a.served, E4.MODELS[a.served], base=a.base, conc=a.conc)
    await verify_served(llm, E4.MODELS[a.served])
    paras = choi_paraphrases()
    print("paraphrase templates:", {f"P{i}": k for i, k in enumerate(paras, 1)} or "NONE FOUND", flush=True)
    conds = expand(a.conds, paras)
    if a.think != "none" and any(c.startswith("CF-") or c == "B0-choi" for c in conds): raise SystemExit("--think supports B0-std, D-*, F-*, R-*, P*, M-*")
    Q = sorted({"nonadopted": cfg.N, "adopted": cfg.A, "all": cfg.A + cfg.N}[a.queries], key=lambda r: r["date"])
    if a.limit: Q = Q[::max(1, len(Q) // a.limit)][:a.limit]
    out = STORE / f"e4_{a.served}_{a.tag}.jsonl"; done = set()
    if out.exists():
        for l in open(out):
            r = json.loads(l)
            if r.get("error") is None: done.add((r["qid"], r["nation"], r["cond"]))
    has_orc = {q["res_id"]: cfg.oracle(q) is not None for q in Q} if any(c.startswith("F-") for c in conds) else {}
    def want(q, n, c):
        if (q["res_id"], n, c) in done: return False
        if c in E4.CONDS and not q["adopted"] and a.think == "none": return True
        if cfg.vot[q["res_id"]][n] not in ("Y", "N", "A"): return False
        return has_orc.get(q["res_id"], True) if c.startswith("F-") else True
    R = W2(llm, cfg, out, a.think, a.budget, paras); t = time.time()
    tasks = [R.run_one(q, n, c) for c in conds for q in Q for n in P5 if want(q, n, c)]
    print(f"{len(tasks)} tasks | {len(Q)} {a.queries} queries | {len(conds)} conditions | think={a.think} | model {a.served}", flush=True)
    await asyncio.gather(*tasks)
    print(f"wall {time.time() - t:.0f}s")
    (LOGS / f"e4_prompt_samples_{a.served}_{a.tag}.txt").write_text("\n\n".join(f"########## {k}\n{v}" for k, v in R.samples.items()))
    rows = [json.loads(l) for l in open(out)] if out.exists() else []
    bad = sum(1 for r in rows if r.get("error")); print(f"rows={len(rows)} error_rows={bad}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--served", required=True); ap.add_argument("--conds", default="wave2"); ap.add_argument("--tag", default="wave2")
    ap.add_argument("--queries", default="nonadopted", choices=["nonadopted", "adopted", "all"]); ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--conc", type=int, default=10); ap.add_argument("--base", default="http://127.0.0.1:8007/v1")
    ap.add_argument("--think", default="none", choices=["none", "off", "on"]); ap.add_argument("--budget", type=int, default=1024)
    asyncio.run(amain(ap.parse_args()))
E5W2
cat > $PROJ/src/coalrag/analysis/e5_analysis.py <<'E5AN'
"""Wave-2 analysis (D60 plan, fixed before results). Usage: python -m coalrag.analysis.e5_analysis <served> [--B 1000]
Reads e4_<served>_{main,wave2,allreg,think-off,think-on}.jsonl when present. Resolution-cluster paired bootstrap.
A evidence factorial and flip test | B order/k | C paraphrases | D memorization | E all regimes | F reasoning mode"""
import argparse, os
from pathlib import Path
import numpy as np, pandas as pd
from coalrag.analysis.e4_metrics import metrics

STORE = Path(os.environ["PROJ"]) / "results" / "store"; K = ["qid", "nation"]; LAB = ["Y", "N", "A"]


def load(m, tag):
    p = STORE / f"e4_{m}_{tag}.jsonl"
    if not p.exists(): return None
    d = pd.read_json(p, lines=True)
    d = d[d.error.isna() & d.true.isin(LAB)].drop_duplicates(K + ["cond"], keep="last").copy()
    P = d[["pY", "pN", "pA"]].values.astype(float)
    d["ptrue"] = P[np.arange(len(d)), d.true.map({"Y": 0, "N": 1, "A": 2}).values]
    d["pred"] = np.array(LAB)[P.argmax(1)]; d["hit"] = (d.pred == d.true).astype(float)
    return d


def stat(name):
    if name in ("ptrue", "hit"): return lambda g: float(g[name].mean())
    return lambda g: metrics(g.true.values, g[["pY", "pN", "pA"]].values.astype(float))[name]


def align(frames):
    keys = set.intersection(*[set(zip(f.qid, f.nation)) for f in frames])
    return [f[[k in keys for k in zip(f.qid, f.nation)]].sort_values(K).reset_index(drop=True) for f in frames]


def paired(a, b, name, B, seed=0):
    a, b = align([a, b]); f = stat(name); q = a.qid.values; uq = np.unique(q)
    pos = {u: np.where(q == u)[0] for u in uq}; rng = np.random.default_rng(seed); bs = []
    for _ in range(B):
        ix = np.concatenate([pos[u] for u in rng.choice(uq, len(uq))]); bs.append(f(a.iloc[ix]) - f(b.iloc[ix]))
    d = f(a) - f(b); lo, hi = np.nanpercentile(bs, [2.5, 97.5]); star = "*" if lo > 0 or hi < 0 else " "
    return f"{d:+.3f} [{lo:+.3f},{hi:+.3f}]{star}"


def table(d, conds, cols=("hit", "ptrue", "macroF1_BC", "aucN", "yes_gap", "no_recall")):
    rows = []
    for c in conds:
        g = d[d.cond == c]
        if len(g): rows.append(dict(cond=c, n=len(g), **{k: round(stat(k)(g), 3) for k in cols}))
    return pd.DataFrame(rows).set_index("cond") if rows else pd.DataFrame()


def main(m, B):
    main_, w2, ar = load(m, "main"), load(m, "wave2"), load(m, "allreg")
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
    if w2 is not None and main_ is not None:
        # ---- A. evidence factorial on the oracle precedent ----
        F = ["F-orc-text", "F-orc-coal", "F-orc-others", "F-orc-flip", "F-rnd-coal", "F-rnd-orcv"]
        base = main_[main_.cond == "B0-std"]; fr = [base] + [w2[w2.cond == c] for c in F if c in set(w2.cond)]
        A = pd.concat(align(fr)); print(f"\n==== A. EVIDENCE FACTORIAL (one oracle precedent; keys={A.groupby('cond').size().min()}) ====")
        print(table(A, ["B0-std"] + F).to_string())
        g = {c: A[A.cond == c] for c in A.cond.unique()}
        C = [("votes | relevant text", "F-orc-coal", "F-orc-text"), ("relevant text | no votes", "F-orc-text", "B0-std"),
             ("correct vs own votes | random text", "F-rnd-orcv", "F-rnd-coal"), ("text relevance | correct votes", "F-orc-coal", "F-rnd-orcv"),
             ("own vote shown vs allies only", "F-orc-coal", "F-orc-others"), ("allies only vs text only", "F-orc-others", "F-orc-text"),
             ("flipped target vote", "F-orc-flip", "F-orc-coal")]
        print("\n-- paired contrasts (cluster bootstrap 95% CI; * = excludes 0) --")
        for lab, x, y in C:
            if x in g and y in g:
                print(f"{lab:38s} {x} - {y}: P(true) {paired(g[x], g[y], 'ptrue', B)} | acc {paired(g[x], g[y], 'hit', B)} | AUROC(N) {paired(g[x], g[y], 'aucN', B)}")
        if "F-orc-flip" in g and "F-orc-text" in g:
            fl, tx = align([g["F-orc-flip"], g["F-orc-text"]])
            col = {"Y": "pY", "N": "pN", "A": "pA"}
            fl["p_shown"] = [r[col[s]] for s, r in zip(fl.shown, fl.to_dict("records"))]
            tx["p_shown"] = [r[col[s]] for s, r in zip(fl.shown, tx.to_dict("records"))]
            fl["uptake"] = fl.p_shown - tx.p_shown; fl["follow"] = (fl.pred == fl.shown).astype(float)
            fl["case"] = fl.true + "->" + fl.shown
            print("\n-- flip test: uptake = P(shown label | flipped evidence) - P(same label | text only); follow = argmax equals shown --")
            print(fl.groupby("case").agg(n=("uptake", "size"), uptake=("uptake", "mean"), follow=("follow", "mean")).round(3).to_string())
            co, tx2 = align([g["F-orc-coal"], g["F-orc-text"]]); co["uptake_true"] = co.ptrue.values - tx2.ptrue.values
            print("-- correct evidence: uptake of the true label by true label --")
            print(co.groupby("true").uptake_true.agg(["size", "mean"]).round(3).to_string())
            a = fl[fl.case == "Y->N"].uptake; b = fl[fl.case == "N->Y"].uptake
            if len(a) and len(b):
                rng = np.random.default_rng(0); bs = [rng.choice(a.values, len(a)).mean() - rng.choice(b.values, len(b)).mean() for _ in range(B)]
                print(f"asymmetry: uptake(shown against | true favour) - uptake(shown favour | true against) = {a.mean() - b.mean():+.3f} "
                      f"[{np.percentile(bs, 2.5):+.3f},{np.percentile(bs, 97.5):+.3f}]")
        # ---- B. order and k ----
        R = ["D-strat4-coal", "R-strat4-rev", "R-strat4-shuf", "R-strat2-coal", "R-strat6-coal", "D-top4-coal"]
        fr = [main_[main_.cond == c] for c in ("B0-std", "D-strat4-coal", "D-top4-coal")] + [w2[w2.cond == c] for c in R[1:5]]
        Rd = pd.concat(align([f for f in fr if len(f)])); gg = {c: Rd[Rd.cond == c] for c in Rd.cond.unique()}
        print("\n==== B. ORDER AND k (stratified evidence, coalition view) ====")
        print(table(Rd, ["B0-std"] + R).to_string())
        for c in R[1:]:
            if c in gg: print(f"{c:15s} - D-strat4-coal: AUROC(N) {paired(gg[c], gg['D-strat4-coal'], 'aucN', B)} | P(true) {paired(gg[c], gg['D-strat4-coal'], 'ptrue', B)}")
        # ---- C. paraphrases ----
        P = sorted({c.split("-")[0] for c in w2.cond if c[0] == "P" and c[1].isdigit()})
        if P:
            rows = []
            for p, (b0, s4) in [("P0 (main)", ("B0-std", "D-strat4-coal"))] + [(p, (f"{p}-B0", f"{p}-strat4")) for p in P]:
                src = main_ if p.startswith("P0") else w2; x, y = src[src.cond == b0], src[src.cond == s4]
                if not len(x) or not len(y): continue
                tpl = "" if p.startswith("P0") else str(x.template.iloc[0])
                rows.append(dict(template=p, name=tpl, yes_rate_B0=(x.pred == "Y").mean(), aucN_B0=stat("aucN")(x), F1BC_B0=stat("macroF1_BC")(x),
                                 aucN_strat4=stat("aucN")(y), F1BC_strat4=stat("macroF1_BC")(y), d_aucN=paired(y, x, "aucN", B)))
            T = pd.DataFrame(rows).set_index("template")
            print("\n==== C. PARAPHRASE ROBUSTNESS (Choi templates) ====\n" + T.round(3).to_string())
            num = T[["yes_rate_B0", "aucN_B0", "aucN_strat4", "F1BC_B0", "F1BC_strat4"]]
            print("mean +- sd across templates:", {k: f"{v:.3f} +- {s:.3f}" for k, v, s in zip(num.columns, num.mean(), num.std())})
        # ---- D. memorization ----
        if "M-symbol" in set(w2.cond):
            M = w2[w2.cond == "M-symbol"]; print("\n==== D. MEMORIZATION PROBE (symbol + date only) ====")
            print(table(M, ["M-symbol"]).to_string(), "| majority-class acc:", round(M.true.value_counts(normalize=True).max(), 3))
            mem = M.set_index(K).ptrue.gt(0.5).rename("memorized")
            for c in ("D-strat4-coal", "D-oracle-coal", "D-bge-coal"):
                x, y = align([main_[main_.cond == c], base])
                j = x.set_index(K).ptrue.sub(y.set_index(K).ptrue).rename("gain").to_frame().join(mem, how="inner")
                print(f"{c:14s} gain in P(true) over B0-std: memorized {j[j.memorized].gain.mean():+.3f} (n={j.memorized.sum()}) | "
                      f"not memorized {j[~j.memorized].gain.mean():+.3f} (n={(~j.memorized).sum()})")
    # ---- E. all regimes ----
    if ar is not None and main_ is not None:
        E = pd.concat([ar, main_[main_.cond.isin(set(ar.cond))]]); print("\n==== E. ALL REGIMES (adopted queries from allreg + non-adopted from main) ====")
        rows = []
        for (c, s), g in E.groupby(["cond", "qset"]):
            notN = g.true != "N"
            rows.append(dict(cond=c, qset=s, n=len(g), yes_rate=(g.pred == "Y").mean(), true_yes=(g.true == "Y").mean(),
                             false_against=((g.pred == "N") & notN).sum() / max(notN.sum(), 1), no_recall=((g.pred == "N") & ~notN).sum() / max((~notN).sum(), 1),
                             F1BC=stat("macroF1_BC")(g)))
        print(pd.DataFrame(rows).set_index(["cond", "qset"]).round(3).to_string())
        print("-- pooled over all queries: AUROC(N) / macro-F1 (BC) --")
        for c in sorted(set(ar.cond)):
            g = E[E.cond == c]; print(f"{c:15s} n={len(g)} AUROC(N)={stat('aucN')(g):.3f} F1BC={stat('macroF1_BC')(g):.3f}")
        for c in sorted(set(ar.cond) - {"B0-std"}):
            x, y = E[E.cond == c], E[E.cond == "B0-std"]
            for s in ["consensus", "split", "vetoed", "failed"]:
                xs, ys = x[x.qset == s], y[y.qset == s]
                if len(xs) and len(ys): print(f"  {c} - B0-std | {s:9s} P(true) {paired(xs, ys, 'ptrue', B)}")
    # ---- F. reasoning mode ----
    th = {t: load(m, t) for t in ("think-off", "think-on")}
    if all(v is not None for v in th.values()):
        print("\n==== F. REASONING MODE (thinking off vs on) ====")
        for t, d in th.items(): print(f"-- {t} --\n" + table(d, list(dict.fromkeys(d.cond))).to_string())
        on, off = th["think-on"], th["think-off"]
        for c in dict.fromkeys(on.cond):
            print(f"{c:15s} on - off: AUROC(N) {paired(on[on.cond == c], off[off.cond == c], 'aucN', B)} | P(true) {paired(on[on.cond == c], off[off.cond == c], 'ptrue', B)}")
        if "reason_tokens" in on: print("reasoning tokens: mean", round(on.reason_tokens.mean()), "| truncated share", round(on.truncated.mean(), 3))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("served"); ap.add_argument("--B", type=int, default=1000)
    a = ap.parse_args(); main(a.served, a.B)
E5AN
cat > $PROJ/src/coalrag/experiments/e1f_depth_embargo.py <<'E1F'
"""E1f on Config A' (581 Choi documents, symmetric text; exact five-vote configuration):
(i) R@k curves; (ii) stage-1 depth for Coalition-Stratified Retrieval (does stratifying deeper recover the R@50 loss?);
(iii) temporal embargo (exclude precedents within delta days: near-duplicate redrafts / leakage, VD1Y-4);
(iv) a training-free regime router: share of contested drafts among the 10 nearest earlier precedents; threshold tuned on
queries before 2013, evaluated on 2013 onwards; realized vs oracle routing between bge (R@1) and CSR3-bge (R@1)."""
import os
from pathlib import Path
import numpy as np, pandas as pd
from coalrag.retrieval.configA import ConfigA
from coalrag.core.match import P5
from coalrag.data.configB import match_vec

PROJ = Path(os.environ["PROJ"]); STORE = PROJ / "results" / "store"
cfg = ConfigA()
docs = sorted(cfg.A + cfg.N, key=lambda r: (r["date"], r["res_id"]))
ids = [d["res_id"] for d in docs]; dates = np.array([np.datetime64(d["date"]) for d in docs])
CODE = {"Y": 1, "N": 2, "A": 3}
V = np.array([[CODE.get(cfg.vot[i][n], 0) for n in P5] for i in ids], dtype=np.int8)
cnt = np.stack([(V == c).sum(1) for c in (1, 2, 3)], 1); tot = cnt.sum(1, keepdims=True)
p = np.where(tot > 0, cnt / np.maximum(tot, 1), 0.0); H = -(np.where(p > 0, p * np.log2(np.where(p > 0, p, 1)), 0)).sum(1) / np.log2(3)
EB = np.stack([cfg.E["bge-small"][cfg.pos[i]] for i in ids])
REG = np.array([(("vetoed" if d["vetoed"] else "failed") if not d["adopted"] else d["regime"]) for d in docs])
CONT = REG != "consensus"
DEPTHS, EMB, KS = [10, 25, 50, 100, 200, 0], [0, 30, 90, 365], [1, 2, 3, 5, 10]

def strat(order):
    seen, out = set(), []
    for j in order:
        key = tuple(V[j])
        if key not in seen: seen.add(key); out.append(j)
    return np.array(out, dtype=int)

def csr(o, s, qi):
    top = o[:50]; dt = (dates[qi] - dates[top]).astype("timedelta64[D]").astype(float)
    tn = (s[top] - s[top].min()) / (s[top].max() - s[top].min() + 1e-9)
    return top[np.argsort(-(H[top] + 0.3 * 0.5 ** (dt / 1825) + 0.2 * tn), kind="stable")]

rows = []
for qi in [i for i in range(len(docs)) if (V[i] > 0).all()]:
    for delta in EMB:
        cut = int(np.searchsorted(dates, dates[qi] - np.timedelta64(delta, "D"), side="left"))
        if cut < 5: continue
        h, _ = match_vec(V[:cut], V[qi], 0, "answer")
        s = EB[:cut] @ EB[qi]; o = np.argsort(-s, kind="stable")
        L = {"bge": o, "CSR3-bge": csr(o, s, qi), "strat-50": strat(o[:50])}
        if delta == 0:
            for d in DEPTHS:
                if d != 50: L[f"strat-{d or 'all'}"] = strat(o[:d] if d else o)
        base = dict(qid=ids[qi], regime=REG[qi], year=int(str(dates[qi])[:4]), delta=delta, n_pool=cut, sup=bool(h.any()),
                    r50=bool(h[o[:50]].any()), p_cont=float(CONT[o[:10]].mean()))
        for name, oo in L.items():
            rows.append({**base, "method": name, "n_cfg": len(oo) if name.startswith("strat") else np.nan,
                         **{f"r{k}": bool(h[oo[:k]].any()) for k in KS}})
df = pd.DataFrame(rows); df.to_parquet(STORE / "e1f_depth_embargo.parquet", index=False)
REGS = ["consensus", "split", "vetoed", "failed"]; pc = lambda x: (100 * x).round(1)
z = df[df.delta == 0]
print(f"queries={z.qid.nunique()} | by regime={z.drop_duplicates('qid').regime.value_counts().reindex(REGS).to_dict()}")

print("\n==== (i) R@k curves, delta=0 (%): bge / CSR3-bge / strat-50 ====")
for m in ["bge", "CSR3-bge", "strat-50"]:
    print(f"-- {m} --\n" + pc(z[z.method == m].groupby("regime")[[f"r{k}" for k in KS]].mean().reindex(REGS)).to_string())

print("\n==== (ii) STAGE-1 DEPTH for stratification, delta=0 (R@3 / R@5 / R@10 %; mean distinct configurations) ====")
D = [f"strat-{d or 'all'}" for d in DEPTHS]; t = z[z.method.isin(D)]
tab = t.groupby(["regime", "method"]).apply(lambda g: f"{100*g.r3.mean():.0f}/{100*g.r5.mean():.0f}/{100*g.r10.mean():.0f} ({g.n_cfg.mean():.1f})").unstack("method")[D].reindex(REGS)
tab["Sup"] = pc(z[z.method == "bge"].groupby("regime").sup.mean()); tab["R50"] = pc(z[z.method == "bge"].groupby("regime").r50.mean())
print(tab.to_string())

rng = np.random.default_rng(0)
def paired(fr, m1, m2, col, B=5000):
    x = fr[fr.method == m1].set_index("qid")[col].astype(int); y = fr[fr.method == m2].set_index("qid")[col].astype(int)
    d = (x - y).dropna().values; ix = rng.integers(0, len(d), (B, len(d))); bs = d[ix].mean(1)
    return f"{100 * d.mean():+5.1f} [{100 * np.percentile(bs, 2.5):+5.1f},{100 * np.percentile(bs, 97.5):+5.1f}]"
print("\n-- paired (pp, bootstrap over queries) --")
for reg in REGS[1:]:
    r = z[z.regime == reg]
    print(f"{reg:9s} R@10 strat-all vs strat-50 {paired(r, 'strat-all', 'strat-50', 'r10')} | R@5 strat-100 vs strat-50 {paired(r, 'strat-100', 'strat-50', 'r5')} "
          f"| R@3 strat-25 vs strat-50 {paired(r, 'strat-25', 'strat-50', 'r3')}")

print("\n==== (iii) TEMPORAL EMBARGO (exclude precedents within delta days), %: Sup | bge R@1 | bge R@10 | CSR3 R@3 | strat-50 R@3 | strat-50 R@10 ====")
E = []
for (dl, reg), g in df.groupby(["delta", "regime"]):
    b, c, s_ = g[g.method == "bge"], g[g.method == "CSR3-bge"], g[g.method == "strat-50"]
    E.append(dict(delta=dl, regime=reg, n=b.qid.nunique(), Sup=b.sup.mean(), bge_R1=b.r1.mean(), bge_R10=b.r10.mean(),
                  CSR3_R3=c.r3.mean(), strat_R3=s_.r3.mean(), strat_R10=s_.r10.mean()))
E = pd.DataFrame(E).set_index(["regime", "delta"]).reindex(REGS, level=0)
print(pd.concat([E[["n"]], pc(E.drop(columns="n"))], axis=1).to_string())
for reg in REGS:
    a = df[(df.regime == reg) & (df.method == "bge")]
    x = a[a.delta == 0].set_index("qid").r1.astype(int); y = a[a.delta == 30].set_index("qid").r1.astype(int)
    d = (y - x).dropna()
    print(f"{reg:9s} bge R@1, delta 30 minus 0: {100 * d.mean():+5.1f} pp (n={len(d)}; queries whose R@1 hit disappears: {int((d < 0).sum())})")

print("\n==== (iv) TRAINING-FREE REGIME ROUTER (contested share among 10 nearest earlier precedents) ====")
w = z[z.method.isin(["bge", "CSR3-bge"])].pivot_table(index=["qid", "regime", "year", "p_cont"], columns="method", values="r1").reset_index()
w["cont"] = w.regime != "consensus"
def auroc(s, y):
    y = np.asarray(y, bool); r = pd.Series(s).rank().values; n1, n0 = y.sum(), (~y).sum()
    return float((r[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)) if n1 and n0 else np.nan
dev, test = w[w.year < 2013], w[w.year >= 2013]
grid = np.round(np.arange(0.0, 1.01, 0.1), 1)
route = lambda f, tau: np.where(f.p_cont >= tau, f["CSR3-bge"], f["bge"]).mean()
tau = max(grid, key=lambda t: route(dev, t))
print(f"dev n={len(dev)} test n={len(test)} | AUROC(p_cont -> contested): dev {auroc(dev.p_cont, dev.cont):.3f}, test {auroc(test.p_cont, test.cont):.3f} | tau*={tau}")
for lab, f in [("dev (<2013)", dev), ("test (>=2013)", test)]:
    reg_or = f.groupby("regime")[["bge", "CSR3-bge"]].mean().max(axis=1).mul(f.regime.value_counts()).sum() / len(f)
    print(f"{lab:13s} R@1 %: bge {100*f.bge.mean():.1f} | CSR3 {100*f['CSR3-bge'].mean():.1f} | routed(tau*) {100*route(f, tau):.1f} | "
          f"oracle regime routing {100*reg_or:.1f}")
E1F
cat > $PROJ/configs/queue_wave2.sh <<'QUEUE'
#!/usr/bin/env bash
# GPU 7 queue (D60). Waits for the 32B main run, then: 32B wave 2 and all-regime run, Mistral-24B-2501, Qwen3-8B thinking
# off/on, Qwen2.5-7B. Every stage resumes from its jsonl, so the script is safe to re-run after an interruption.
set -u
source $HOME/miniforge3/etc/profile.d/conda.sh
export PROJ=$HOME/coalrag PYTHONPATH=$HOME/coalrag/src
Q=$PROJ/logs/queue_wave2.log
say() { echo "[$(date '+%m-%d %H:%M:%S')] $*" | tee -a $Q; }
served() { curl -s 127.0.0.1:8007/v1/models | python -c "import sys,json; print(json.load(sys.stdin)['data'][0]['id'])" 2>/dev/null; }
serve() {  # $1 checkpoint dir, $2 served name, rest = vllm args
  local M=$1 N=$2; shift 2
  [ "$(served)" = "$N" ] && { say "reuse server $N"; return 0; }
  [ -d "$M" ] || { say "SKIP $N: $M not on disk"; return 1; }
  pkill -u $USER -f "vllm serve"; sleep 20
  conda activate crag-vllm
  CUDA_VISIBLE_DEVICES=7 nohup vllm serve $M --served-model-name $N --host 127.0.0.1 --port 8007 --seed 0 "$@" > $PROJ/logs/vllm_$N.log 2>&1 &
  echo $! > $PROJ/logs/vllm.pid
  conda activate crag
  for i in $(seq 1 240); do
    [ "$(served)" = "$N" ] && { say "served $N | $(grep -h 'KV cache size' $PROJ/logs/vllm_$N.log | tail -1 | sed 's/.*GPU //')"; return 0; }
    kill -0 $(cat $PROJ/logs/vllm.pid) 2>/dev/null || break; sleep 5
  done
  say "SERVE FAILED $N"; tail -5 $PROJ/logs/vllm_$N.log >> $Q; return 1
}
run() {  # $1 served name, rest = e5_wave2 args; two passes so transient errors are retried
  local N=$1; shift; say "start $N $*"
  for pass in 1 2; do python -W ignore -m coalrag.experiments.e5_wave2 --served $N "$@" >> $PROJ/logs/e5_$N.log 2>&1; done
  say "end   $N $* | $(grep -E '^rows=' $PROJ/logs/e5_$N.log | tail -1)"
}

say "queue started; waiting for the 32B main run"
while pgrep -u $USER -f "e4_llm.*--tag main" >/dev/null; do sleep 120; done
say "32B main run finished"
if serve $HOME/models/Qwen2.5-32B-Instruct-GPTQ-Int8 qwen2.5-32b-gptq-int8 --max-model-len 8192 --gpu-memory-utilization 0.93 --max-num-seqs 12 --max-num-batched-tokens 4096; then
  run qwen2.5-32b-gptq-int8 --conds wave2 --tag wave2 --conc 10
  run qwen2.5-32b-gptq-int8 --conds AR --queries adopted --tag allreg --conc 10
fi
if serve $HOME/models/Mistral-Small-24B-Instruct-2501-FP8-dynamic mistral-small-24b-2501-fp8 --max-model-len 8192 --gpu-memory-utilization 0.92 --max-num-seqs 24; then
  run mistral-small-24b-2501-fp8 --conds main --tag main --conc 16
  run mistral-small-24b-2501-fp8 --conds F,M --tag wave2 --conc 16
fi
if serve $HOME/models/Qwen3-8B qwen3-8b --max-model-len 8192 --gpu-memory-utilization 0.90 --max-num-seqs 48; then
  run qwen3-8b --conds THINK --think off --tag think-off --conc 48
  run qwen3-8b --conds THINK --think on --tag think-on --conc 48 --budget 1024
fi
if serve /mnt/nvme01/huggingface/models/Qwen/Qwen2.5-7B-Instruct qwen2.5-7b --max-model-len 16384 --gpu-memory-utilization 0.85; then
  run qwen2.5-7b --conds main --tag main --conc 48
  run qwen2.5-7b --conds F,M --tag wave2 --conc 48
fi
say "queue complete"
QUEUE
chmod +x $PROJ/configs/queue_wave2.sh
python - <<'PATCHM'
import os
p = os.path.expandvars("$PROJ/src/coalrag/analysis/e4_metrics.py"); s = open(p).read()
if "def relabel" not in s:
    R = [("def main(path, ref, B, by, cad, show):",
          '''def relabel(df, ver):
    """D61: replace stored truth with the votes of CKG <ver> (e.g. v1_2); rows without a recorded vote are dropped."""
    import os
    P5 = ["CHN", "FRA", "GBR", "RUS", "USA"]
    ck = pd.read_parquet(Path(os.environ["PROJ"]) / "data" / "processed" / f"ckg_{ver}.parquet")
    m = {(r["res_id"], n): (r[n] if isinstance(r[n], str) else None) for r in ck[["res_id"] + P5].to_dict("records") for n in P5}
    new = [m.get((q, n), t) for q, n, t in zip(df.qid, df.nation, df.true)]
    ch = sum((a or "") != (b or "") for a, b in zip(new, df.true)); df = df.assign(true=new); keep = df.true.isin(list(L))
    print(f"[truth={ver}] relabelled {ch} rows | dropped {int((~keep).sum())} rows without a recorded vote"); return df[keep]

def main(path, ref, B, by, cad, show, truth=""):'''),
         ('    df = pd.read_json(path, lines=True); df = df[df.error.isna()].drop_duplicates(["qid", "nation", "cond"], keep="last")',
          '    df = pd.concat([pd.read_json(x, lines=True) for x in path.split(",")], ignore_index=True)\n'
          '    df = df[df.error.isna()].drop_duplicates(["qid", "nation", "cond"], keep="last")\n'
          '    if truth: df = relabel(df, truth)'),
         ('    ap.add_argument("--show", default="")', '    ap.add_argument("--show", default=""); ap.add_argument("--truth", default="")'),
         ("main(a.path, a.ref, a.B, a.by, a.cad, a.show)", "main(a.path, a.ref, a.B, a.by, a.cad, a.show, a.truth)")]
    for old, new in R:
        assert s.count(old) == 1, f"patch anchor not found: {old[:60]}"
        s = s.replace(old, new)
    open(p, "w").write(s)
print("e4_metrics: --truth and comma-separated paths", "OK" if "def relabel" in s else "MISSING")
PATCHM
grep -q "^H8 Causal evidence use" $PROJ/configs/prereg.md || cat >> $PROJ/configs/prereg.md <<'PREREG'

## Wave 2 (added 2026-10-02, before any wave-2 output exists; analysis = src/coalrag/analysis/e5_analysis.py)
H8 Causal evidence use: P(true) is higher with the oracle precedent's votes shown than with its text only (F-orc-coal > F-orc-text), and flipping the displayed target vote lowers P(true) (F-orc-flip < F-orc-coal).
H9 Evidence-level affirmative prior: uptake of a displayed 'against' when the truth is favour is smaller than uptake of a displayed 'favour' when the truth is against (uptake measured against the text-only arm).
H10 Coalition inference: the other four members' votes alone raise AUROC(P against) over text only (F-orc-others > F-orc-text).
H11 Robustness: the sign of AUROC(N) for D-strat4-coal minus B0-std holds under every discovered Choi paraphrase and under reversed and shuffled precedent order.
H12 No false-veto cost: on adopted consensus drafts, D-strat4-coal does not significantly raise the false-against rate over B0-std.
Descriptive only: memorization split (M-symbol), k = 2/4/6, Qwen3 thinking on vs off, Mistral-24B-2501 and Qwen2.5-7B replications.
PREREG
grep -q "^- D56" $PROJ/configs/DECISIONS.md || cat >> $PROJ/configs/DECISIONS.md <<'DEC'
- D56 The 32B main run spans two server configurations (rows 1-1332: util 0.80, max-len 4096, eager; later rows: util 0.93, max-len 8192). Max prompt 3,728 tokens, so nothing was truncated. Equivalence checked by re-scoring 30 early rows on the new server (Cell 39a).
- D57 Majority-aligned metrics hide dissent failures: target-vote match (BM25, Western, vetoed: 83% target vote vs 11% coalition@1) and HDA against historical references (always-favour B0-choi scores above the true-label distribution) both reward the affirmative prior. Primary metrics stay exact configuration/coalition match and AUROC(N), BC-F1, Yes-gap; HDA is reported against the true-label reference, historical references only as a prior-conformity diagnostic.
- D58 E3 ladder: the informativeness term is the harmful CSR-v6 component (vetoed -29.8 pp [-38.6, -21.1]; it rewards votes that are rare for the target, i.e. the opposite of the expected vote when the target is in the majority); the dev-tuned weight is 0. v1 Table 3 contested numbers are not reproduced after vote repair (D29). CSR-v6 is reported as a documented negative in Appendix H.
- D59 Missing votes are never imputed: uniform imputation (convention c) costs 15-20 pp target-vote@1; conventions a and b coincide on CKG v1.2.
- D60 Wave 2 pre-registered (prereg H8-H12) before any wave-2 output: F factorial on the oracle precedent, R order/k, P Choi paraphrases, M memorization probe, AR all-regime run, Qwen3-8B thinking off/on; Mistral-24B-2501 and Qwen2.5-7B replications; E1f depth, embargo and training-free router on Config A'.
- D61 LLM metrics are reported with the stored truth (CKG v1.1, pre-registered) and, where they differ, with --truth v1_2.
DEC
python -m py_compile src/coalrag/experiments/e5_wave2.py src/coalrag/analysis/e5_analysis.py src/coalrag/experiments/e1f_depth_embargo.py && bash -n configs/queue_wave2.sh
git add -A && git -c user.name=becky1 -c user.email=becky1@andlab commit -qm "wave 2: runner, analysis, E1f, queue; prereg H8-H12; D56-D61" && git log -1 --format="WAVE2 PREREG commit %h %ad" || echo "nothing new to commit"
