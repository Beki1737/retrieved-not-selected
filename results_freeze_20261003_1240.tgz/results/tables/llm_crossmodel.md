# LLM results across models

Cell = macro-F1 after Batch Calibration / AUROC of P(against) / Yes-rate gap / No-recall

```
model                            llama-3.3-70b-fp8    mistral-small-24b-2501-fp8         qwen2.5-32b-gptq-int8                    qwen2.5-7b
cond                                                                                                                                        
BL-majority           0.157 / 0.500 / +0.48 / 0.00  0.157 / 0.500 / +0.48 / 0.00  0.157 / 0.500 / +0.48 / 0.00  0.157 / 0.500 / +0.48 / 0.00
BL-nation-all         0.327 / 0.582 / +0.48 / 0.00  0.327 / 0.582 / +0.48 / 0.00  0.327 / 0.582 / +0.48 / 0.00  0.327 / 0.582 / +0.48 / 0.00
BL-nation-nonadopted  0.440 / 0.602 / +0.22 / 0.25  0.440 / 0.602 / +0.22 / 0.25  0.440 / 0.602 / +0.22 / 0.25  0.440 / 0.602 / +0.22 / 0.25
BL-copy-bge1          0.401 / 0.576 / +0.24 / 0.27  0.401 / 0.576 / +0.24 / 0.27  0.401 / 0.576 / +0.24 / 0.27  0.401 / 0.576 / +0.24 / 0.27
BL-knn10              0.466 / 0.604 / +0.41 / 0.08  0.466 / 0.604 / +0.41 / 0.08  0.466 / 0.604 / +0.41 / 0.08  0.466 / 0.604 / +0.41 / 0.08
BL-strat4-vote        0.459 / 0.623 / +0.31 / 0.19  0.459 / 0.623 / +0.31 / 0.19  0.459 / 0.623 / +0.31 / 0.19  0.459 / 0.623 / +0.31 / 0.19
B0-choi               0.513 / 0.719 / +0.05 / 0.49  0.449 / 0.625 / -0.37 / 0.10  0.413 / 0.685 / +0.06 / 0.13  0.267 / 0.551 / +0.45 / 0.07
B0-std                0.498 / 0.696 / -0.07 / 0.34  0.483 / 0.667 / -0.38 / 0.27  0.474 / 0.670 / +0.00 / 0.27  0.270 / 0.543 / +0.40 / 0.08
CF-LTorig             0.471 / 0.700 / +0.01 / 0.36  0.476 / 0.679 / -0.14 / 0.35  0.455 / 0.676 / +0.05 / 0.22  0.372 / 0.588 / +0.35 / 0.17
CF-LT                                          NaN  0.463 / 0.675 / -0.10 / 0.37  0.488 / 0.693 / +0.09 / 0.26  0.327 / 0.586 / +0.36 / 0.14
CF-bge                                         NaN  0.513 / 0.680 / -0.11 / 0.44  0.465 / 0.664 / +0.06 / 0.30  0.373 / 0.606 / +0.30 / 0.17
CF-CSR3                                        NaN  0.460 / 0.623 / -0.15 / 0.36  0.447 / 0.625 / +0.02 / 0.25  0.375 / 0.574 / +0.29 / 0.16
D-bge-text                                     NaN  0.502 / 0.699 / -0.37 / 0.35  0.469 / 0.698 / -0.02 / 0.25  0.293 / 0.577 / +0.41 / 0.06
D-bge-target                                   NaN  0.504 / 0.689 / -0.05 / 0.37  0.478 / 0.685 / +0.11 / 0.30  0.327 / 0.576 / +0.39 / 0.15
D-bge-coal            0.532 / 0.742 / +0.01 / 0.45  0.504 / 0.684 / -0.08 / 0.39  0.488 / 0.688 / +0.09 / 0.28  0.329 / 0.561 / +0.38 / 0.12
D-random-coal         0.474 / 0.683 / +0.07 / 0.33  0.488 / 0.655 / -0.04 / 0.28  0.441 / 0.662 / +0.16 / 0.23  0.305 / 0.541 / +0.40 / 0.11
D-oracle-coal         0.579 / 0.836 / +0.02 / 0.46  0.631 / 0.862 / -0.07 / 0.50  0.546 / 0.765 / +0.12 / 0.29  0.348 / 0.637 / +0.39 / 0.13
D-top4-coal                                    NaN  0.524 / 0.675 / -0.04 / 0.32  0.499 / 0.668 / +0.08 / 0.33  0.374 / 0.594 / +0.35 / 0.18
D-strat4-target                                NaN  0.536 / 0.709 / -0.06 / 0.37  0.464 / 0.693 / +0.08 / 0.27  0.365 / 0.577 / +0.35 / 0.16
D-strat4-coal         0.522 / 0.732 / +0.04 / 0.46  0.521 / 0.691 / -0.06 / 0.37  0.514 / 0.694 / +0.05 / 0.34  0.348 / 0.587 / +0.33 / 0.20
D-random-coal+CAD1    0.432 / 0.639 / +0.12 / 0.33  0.411 / 0.601 / +0.12 / 0.24  0.438 / 0.616 / +0.19 / 0.27  0.343 / 0.499 / +0.35 / 0.16
D-oracle-coal+CAD1    0.609 / 0.858 / +0.06 / 0.54  0.666 / 0.868 / +0.06 / 0.55  0.541 / 0.761 / +0.18 / 0.41  0.408 / 0.655 / +0.31 / 0.25
D-strat4-coal+CAD1    0.552 / 0.722 / +0.06 / 0.55  0.491 / 0.672 / +0.07 / 0.35  0.452 / 0.669 / +0.09 / 0.35  0.386 / 0.588 / +0.21 / 0.32
```

## Pre-registered tests (one-sided, resolution-cluster bootstrap; Holm within model over H5-H7; H7-control and E-baseline rows are exploratory)

```
                     model        hyp     metric                  a                    b  delta               ci      p p_holm
         llama-3.3-70b-fp8         H5       aucN      D-strat4-coal               B0-std +0.036 [-0.004, +0.077] 0.0410 0.1639
         llama-3.3-70b-fp8         H5       aucN      D-oracle-coal               B0-std +0.140 [+0.091, +0.191] 0.0005 0.0035
         llama-3.3-70b-fp8         H5 macroF1_BC      D-oracle-coal        D-random-coal +0.105 [+0.051, +0.174] 0.0010 0.0060
         llama-3.3-70b-fp8         H6 macroF1_BC      D-strat4-coal               B0-std +0.024 [-0.041, +0.085] 0.2514 0.2789
         llama-3.3-70b-fp8         H6 macroF1_BC      D-oracle-coal               B0-std +0.081 [+0.012, +0.151] 0.0090 0.0450
         llama-3.3-70b-fp8         H7 macroF1_BC D-strat4-coal+CAD1        D-strat4-coal +0.029 [-0.022, +0.081] 0.1219 0.2789
         llama-3.3-70b-fp8         H7 macroF1_BC D-oracle-coal+CAD1        D-oracle-coal +0.030 [-0.013, +0.067] 0.0930 0.2789
         llama-3.3-70b-fp8 H7-control macroF1_BC D-random-coal+CAD1        D-random-coal -0.042 [-0.084, +0.004] 0.9630       
         llama-3.3-70b-fp8 E-baseline macroF1_BC             B0-std BL-nation-nonadopted +0.058 [-0.005, +0.135] 0.0360       
         llama-3.3-70b-fp8 E-baseline       aucN             B0-std BL-nation-nonadopted +0.094 [+0.011, +0.181] 0.0140       
         llama-3.3-70b-fp8 E-baseline macroF1_BC      D-strat4-coal       BL-strat4-vote +0.064 [-0.005, +0.136] 0.0350       
         llama-3.3-70b-fp8 E-baseline       aucN      D-strat4-coal             BL-knn10 +0.128 [+0.020, +0.242] 0.0095       
         llama-3.3-70b-fp8 E-baseline macroF1_BC      D-oracle-coal             BL-knn10 +0.113 [+0.043, +0.197] 0.0010       
mistral-small-24b-2501-fp8         H5       aucN      D-strat4-coal               B0-std +0.024 [-0.029, +0.085] 0.1939 0.3878
mistral-small-24b-2501-fp8         H5       aucN      D-oracle-coal               B0-std +0.195 [+0.124, +0.271] 0.0005 0.0035
mistral-small-24b-2501-fp8         H5 macroF1_BC      D-oracle-coal        D-random-coal +0.143 [+0.084, +0.209] 0.0005 0.0035
mistral-small-24b-2501-fp8         H6 macroF1_BC      D-strat4-coal               B0-std +0.038 [-0.017, +0.095] 0.0740 0.2959
mistral-small-24b-2501-fp8         H6 macroF1_BC      D-oracle-coal               B0-std +0.148 [+0.088, +0.217] 0.0005 0.0035
mistral-small-24b-2501-fp8         H7 macroF1_BC D-strat4-coal+CAD1        D-strat4-coal -0.030 [-0.069, +0.017] 0.8846 0.8846
mistral-small-24b-2501-fp8         H7 macroF1_BC D-oracle-coal+CAD1        D-oracle-coal +0.035 [-0.017, +0.075] 0.1094 0.3283
mistral-small-24b-2501-fp8 H7-control macroF1_BC D-random-coal+CAD1        D-random-coal -0.077 [-0.121, -0.026] 0.9985       
mistral-small-24b-2501-fp8 E-baseline macroF1_BC             B0-std BL-nation-nonadopted +0.043 [-0.025, +0.118] 0.0965       
mistral-small-24b-2501-fp8 E-baseline       aucN             B0-std BL-nation-nonadopted +0.065 [-0.024, +0.149] 0.0780       
mistral-small-24b-2501-fp8 E-baseline macroF1_BC      D-strat4-coal       BL-strat4-vote +0.062 [-0.007, +0.139] 0.0405       
mistral-small-24b-2501-fp8 E-baseline       aucN      D-strat4-coal             BL-knn10 +0.087 [-0.005, +0.182] 0.0315       
mistral-small-24b-2501-fp8 E-baseline macroF1_BC      D-oracle-coal             BL-knn10 +0.165 [+0.095, +0.248] 0.0005       
     qwen2.5-32b-gptq-int8         H5       aucN      D-strat4-coal               B0-std +0.024 [-0.023, +0.075] 0.1614 0.4843
     qwen2.5-32b-gptq-int8         H5       aucN      D-oracle-coal               B0-std +0.095 [+0.043, +0.149] 0.0005 0.0035
     qwen2.5-32b-gptq-int8         H5 macroF1_BC      D-oracle-coal        D-random-coal +0.105 [+0.056, +0.148] 0.0005 0.0035
     qwen2.5-32b-gptq-int8         H6 macroF1_BC      D-strat4-coal               B0-std +0.040 [-0.020, +0.101] 0.0950 0.3798
     qwen2.5-32b-gptq-int8         H6 macroF1_BC      D-oracle-coal               B0-std +0.071 [-0.007, +0.137] 0.0340 0.1699
     qwen2.5-32b-gptq-int8         H7 macroF1_BC D-strat4-coal+CAD1        D-strat4-coal -0.062 [-0.125, -0.001] 0.9760 1.0000
     qwen2.5-32b-gptq-int8         H7 macroF1_BC D-oracle-coal+CAD1        D-oracle-coal -0.005 [-0.061, +0.057] 0.5042 1.0000
     qwen2.5-32b-gptq-int8 H7-control macroF1_BC D-random-coal+CAD1        D-random-coal -0.003 [-0.075, +0.056] 0.5807       
     qwen2.5-32b-gptq-int8 E-baseline macroF1_BC             B0-std BL-nation-nonadopted +0.034 [-0.014, +0.096] 0.0775       
     qwen2.5-32b-gptq-int8 E-baseline       aucN             B0-std BL-nation-nonadopted +0.068 [-0.015, +0.149] 0.0565       
     qwen2.5-32b-gptq-int8 E-baseline macroF1_BC      D-strat4-coal       BL-strat4-vote +0.056 [-0.021, +0.140] 0.0840       
     qwen2.5-32b-gptq-int8 E-baseline       aucN      D-strat4-coal             BL-knn10 +0.089 [-0.006, +0.192] 0.0320       
     qwen2.5-32b-gptq-int8 E-baseline macroF1_BC      D-oracle-coal             BL-knn10 +0.079 [+0.005, +0.155] 0.0190       
                qwen2.5-7b         H5       aucN      D-strat4-coal               B0-std +0.044 [-0.014, +0.107] 0.0775 0.1549
                qwen2.5-7b         H5       aucN      D-oracle-coal               B0-std +0.094 [+0.041, +0.148] 0.0010 0.0070
                qwen2.5-7b         H5 macroF1_BC      D-oracle-coal        D-random-coal +0.043 [+0.017, +0.100] 0.0025 0.0150
                qwen2.5-7b         H6 macroF1_BC      D-strat4-coal               B0-std +0.077 [+0.013, +0.122] 0.0140 0.0560
                qwen2.5-7b         H6 macroF1_BC      D-oracle-coal               B0-std +0.077 [+0.018, +0.125] 0.0065 0.0325
                qwen2.5-7b         H7 macroF1_BC D-strat4-coal+CAD1        D-strat4-coal +0.039 [-0.029, +0.101] 0.1449 0.1549
                qwen2.5-7b         H7 macroF1_BC D-oracle-coal+CAD1        D-oracle-coal +0.060 [-0.002, +0.113] 0.0330 0.0990
                qwen2.5-7b H7-control macroF1_BC D-random-coal+CAD1        D-random-coal +0.038 [+0.003, +0.091] 0.0200       
                qwen2.5-7b E-baseline macroF1_BC             B0-std BL-nation-nonadopted -0.170 [-0.228, -0.077] 1.0000       
                qwen2.5-7b E-baseline       aucN             B0-std BL-nation-nonadopted -0.058 [-0.152, +0.031] 0.9010       
                qwen2.5-7b E-baseline macroF1_BC      D-strat4-coal       BL-strat4-vote -0.111 [-0.188, -0.029] 0.9950       
                qwen2.5-7b E-baseline       aucN      D-strat4-coal             BL-knn10 -0.017 [-0.107, +0.076] 0.6442       
                qwen2.5-7b E-baseline macroF1_BC      D-oracle-coal             BL-knn10 -0.119 [-0.184, -0.033] 0.9985       
```